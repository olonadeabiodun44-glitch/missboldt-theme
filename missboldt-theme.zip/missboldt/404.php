<?php
get_header(); ?>
<section class="phero"><div class="wrap" style="display:block">
  <h1 class="disp" style="font-size:clamp(40px,6vw,90px)"><?php echo esc_html( is_404() ? 'Page not found' : ( is_singular() ? get_the_title() : get_bloginfo( 'name' ) ) ); ?></h1>
</div></section>
<section class="light" style="padding:80px 0"><div class="wrap" style="max-width:860px">
<?php if ( is_404() ) { ?><p>Sorry, this page does not exist. <a href="<?php echo mb_url(); ?>" style="color:var(--magenta)">Go to the home page</a>.</p><?php }
else { while ( have_posts() ) { the_post(); ?><article style="font-size:18px;line-height:1.7"><?php the_content(); ?></article><?php } } ?>
</div></section>
<?php get_footer();
