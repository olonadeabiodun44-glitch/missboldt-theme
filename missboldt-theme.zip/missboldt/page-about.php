<?php
/* page-about */
get_header(); ?>
<section class="phero"><div class="pnum">03</div><div class="wrap">
  <div class="reveal">
    <div class="crumb"><a href="<?php echo mb_url('',''); ?>" data-i18n="crHome">Home</a> <span>/</span> <b data-i18n="nAbout">About &amp; Talks</b></div>
    <h1 class="disp" data-i18n="aboutH1">About <span class="it">&amp; talks</span></h1>
    <p class="lead" data-i18n="aboutLead">The artist, her story and the messages she brings to the stage.</p>
    <div class="statline"><div><b>6<i>+</i></b><small data-i18n="s1">years of healing work</small></div><div><b>500<i>+</i></b><small data-i18n="b1">people coached</small></div><div><b>3</b><small data-i18n="s3">languages: EN · DE · Akan</small></div></div>
  </div>
  <div class="collage reveal"><div class="sunlet"></div><div class="c c1"><img src="<?php echo esc_url( MB_URI ); ?>/img/bw.jpg" style="object-position:50% 20%" alt="Black and white portrait of Niomi Boldt, wellness speaker and life coach"></div><div class="c c2"><img src="<?php echo esc_url( MB_URI ); ?>/img/nature.jpg" style="object-position:50% 40%" alt="Niomi Boldt outdoors in nature with a colourful scarf"></div></div>
</div></section>
<!-- ABOUT -->
<section class="about" id="story"><div class="wrap grid">
  <div class="pics reveal">
    <div class="pic a"><img src="<?php echo esc_url( MB_URI ); ?>/img/bw.jpg" alt="Niomi Boldt portrait"><span><b>Niomi Boldt</b>VOICE · MOVEMENT</span></div>
    <div class="pic b"><img src="<?php echo esc_url( MB_URI ); ?>/img/nature.jpg" alt="Niomi Boldt in nature"><span><b>Miss Boldt</b>HEALING · NATURE</span></div>
  </div>
  <div class="reveal">
    <div class="kicker" data-i18n="k4">The artist</div>
    <h2 class="disp" data-i18n="h2about">A spiritual <span class="it">warrior</span></h2>
    <p data-i18n="pabout">Standing against violence and inequality with <b>music and movement</b>. Six years of turning pain into wisdom, and wisdom into healing for others.</p>
    <p style="margin-top:18px" data-i18n="storyP2">Her approach, ENTER~wellness, blends entertainment and wellness: music, movement and a healthy, active lifestyle, together with nature, to activate healing in body, mind and soul.</p>
    <div class="stats">
      <div><b>6<i>+</i></b><small data-i18n="s1">years of healing work</small></div>
      <div><b>3<i>in</i>1</b><small data-i18n="s2">talk, song &amp; dance</small></div>
      <div><b>3</b><small data-i18n="s3">languages: EN · DE · Akan</small></div>
    </div>
    <div class="sig"><span class="s">Miss Boldt</span><small>FOUNDER<br>ENTER~WELLNESS</small></div>
  </div>
</div></section>

<section class="coaching" id="coaching"><div class="wrap">
  <div class="head reveal"><div><div class="kicker" data-i18n="coachK">Wellness coaching</div><h2 class="disp" data-i18n="coachH2">Artist <span class="it orchid">who coaches</span></h2></div><p data-i18n="coachP2">Over 500 people in Ghana and abroad, guided through their wellness journey.</p></div>
  <div class="c3">
    <div class="cc reveal"><span class="n">01</span><div class="ci"><svg width="26" height="26" fill="none" stroke="currentColor" stroke-width="1.8"><path d="M5 3v8a3 3 0 006 0V3M8 3v20M19 3c-2 2-3 5-3 8h3v12"/></svg></div><h3 data-i18n="p1">Meal planning</h3><p data-i18n="cc1">Simple, nourishing plans that fit real life and real budgets.</p></div>
    <div class="cc reveal"><span class="n">02</span><div class="ci"><svg width="26" height="26" fill="none" stroke="currentColor" stroke-width="1.8"><path d="M3 10v6M7 7v12M17 7v12M21 10v6M7 13h10"/></svg></div><h3 data-i18n="p2">Basic exercises</h3><p data-i18n="cc2">Easy movement routines anyone can start today, at home or outside.</p></div>
    <div class="cc reveal"><span class="n">03</span><div class="ci"><svg width="26" height="26" fill="none" stroke="currentColor" stroke-width="1.8"><path d="M12 3a6 6 0 00-6 6c0 2 1 3 2 4v3h8v-3c1-1 2-2 2-4a6 6 0 00-6-6zM9 20h6M10 23h4"/></svg></div><h3 data-i18n="p3">Lifestyle mindset</h3><p data-i18n="cc3">Building a strong, consistent mindset that makes change last.</p></div>
  </div>
  <div class="nineblock" id="nine">
  <div class="ninehead reveal">
    <div class="nn">9</div>
    <div><div class="kicker" data-i18n="nineK">Her healing philosophy</div><h3 class="disp" data-i18n="nineH2">Natural ways <span class="it">to heal</span></h3>
    <p data-i18n="nineP2">Healing with music and body movement, grounded in nature, belief, lifestyle and celebration.</p></div>
  </div>
  <div class="hlegend reveal"><span><i class="hl-p"></i><b data-i18n="gPerform">On stage</b></span><span><i class="hl-b"></i><b data-i18n="gBody">Body &amp; lifestyle</b></span><span><i class="hl-s"></i><b data-i18n="gSpirit">Spirit &amp; joy</b></span></div>
  <div class="hgrid"><button class="hm reveal hm-perform" data-method="Dance to heal"><span class="hn">01</span><span class="hi"><svg width="26" height="26" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round"><circle cx="14" cy="4" r="2"/><path d="M6 10l5-2 4 3 4-2M11 8l-1 7-4 6M10 15l5 2 1 5"/></svg></span><h3 data-i18n="hm1">Dance to heal</h3><p data-i18n="hm1p">Move your story out of the body and let emotions flow.</p><span class="hadd" data-i18n="hmAdd">Add to my request +</span></button><button class="hm reveal hm-perform" data-method="Sing to heal"><span class="hn">02</span><span class="hi"><svg width="26" height="26" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round"><path d="M9 18V5l11-2v13"/><circle cx="6" cy="18" r="3"/><circle cx="17" cy="16" r="3"/></svg></span><h3 data-i18n="hm2">Sing to heal</h3><p data-i18n="hm2p">Your voice carries healing vibrations, for you and others.</p><span class="hadd" data-i18n="hmAdd">Add to my request +</span></button><button class="hm reveal hm-spirit" data-method="Be a child to heal"><span class="hn">03</span><span class="hi"><svg width="26" height="26" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="9" r="6"/><path d="M12 15l-1 2h2l-1 2v4"/><path d="M10 8h.01M14 8h.01M10 11c1 1 3 1 4 0"/></svg></span><h3 data-i18n="hm3">Be a child to heal</h3><p data-i18n="hm3p">Play, laugh and reconnect with your inner child.</p><span class="hadd" data-i18n="hmAdd">Add to my request +</span></button><button class="hm reveal hm-perform" data-method="Speak to heal"><span class="hn">04</span><span class="hi"><svg width="26" height="26" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round"><path d="M21 12a8 8 0 01-11.8 7L3 21l2-5.5A8 8 0 1121 12z"/><path d="M8 11h8M8 14h5"/></svg></span><h3 data-i18n="hm4">Speak to heal</h3><p data-i18n="hm4p">Honest words and shared stories that set the heart free.</p><span class="hadd" data-i18n="hmAdd">Add to my request +</span></button><button class="hm reveal hm-body" data-method="Eat to heal"><span class="hn">05</span><span class="hi"><svg width="26" height="26" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round"><path d="M4 12h16a8 8 0 01-16 0z"/><path d="M12 8c0-3 2-5 5-5-0 3-2 5-5 5zM12 8C11 6 9 5 7 5"/></svg></span><h3 data-i18n="hm5">Eat to heal</h3><p data-i18n="hm5p">Nourishing food and simple meal plans that fuel your life.</p><span class="hadd" data-i18n="hmAdd">Add to my request +</span></button><button class="hm reveal hm-body" data-method="Fitness & flexibility"><span class="hn">06</span><span class="hi"><svg width="26" height="26" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round"><path d="M3 10v4M6 7v10M18 7v10M21 10v4M6 12h12"/></svg></span><h3 data-i18n="hm6">Fitness & flexibility</h3><p data-i18n="hm6p">Easy movement and stretching for a strong, free body.</p><span class="hadd" data-i18n="hmAdd">Add to my request +</span></button><button class="hm reveal hm-body" data-method="Self care & love"><span class="hn">07</span><span class="hi"><svg width="26" height="26" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round"><path d="M12 21s-8-5-8-11a4.5 4.5 0 018-3 4.5 4.5 0 018 3c0 6-8 11-8 11z"/></svg></span><h3 data-i18n="hm7">Self care & love</h3><p data-i18n="hm7p">Rest, kindness and knowing your own worth.</p><span class="hadd" data-i18n="hmAdd">Add to my request +</span></button><button class="hm reveal hm-spirit" data-method="Believe to heal"><span class="hn">08</span><span class="hi"><svg width="26" height="26" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round"><path d="M12 3v14M8 7h8"/><path d="M5 13c0 4 3 7 7 7s7-3 7-7"/><path d="M5 13l-2 2M19 13l2 2"/></svg></span><h3 data-i18n="hm8">Believe to heal</h3><p data-i18n="hm8p">Faith and inner strength: the anchor that holds you steady.</p><span class="hadd" data-i18n="hmAdd">Add to my request +</span></button><button class="hm reveal hm-spirit" data-method="Celebrate to heal"><span class="hn">09</span><span class="hi"><svg width="26" height="26" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round"><path d="M3 21l6-15 9 9z"/><path d="M14 3v2M19 5l-1.5 1.5M21 10h-2M16 2l.5 1.5"/></svg></span><h3 data-i18n="hm9">Celebrate to heal</h3><p data-i18n="hm9p">Gratitude and joy: celebrate every step of your life.</p><span class="hadd" data-i18n="hmAdd">Add to my request +</span></button></div>
  <div class="ninecta reveal"><p data-i18n="nineCta">Choose the ways that speak to you, for your event or your own journey.</p><button class="btn solid" data-role="Life coaching"><span data-i18n="startJ">Start your journey</span> →</button></div>
</div>
  <div class="proof">
    <div class="tf reveal">
  <figure class="tf-b"><img src="<?php echo esc_url( MB_URI ); ?>/img/before.jpg" alt="Niomi Boldt before her transformation"><figcaption><small data-i18n="before">BEFORE</small><b data-i18n="tfB">Where it started</b></figcaption></figure>
  <div class="tf-mid"><span class="ar">→</span><span class="vt" data-i18n="tfT">TRANSFORMATION</span></div>
  <figure class="tf-a"><img src="<?php echo esc_url( MB_URI ); ?>/img/after.jpg" alt="Niomi Boldt after her transformation"><figcaption><small data-i18n="after">AFTER</small><b data-i18n="tfA">Living it today</b></figcaption></figure>
  <span class="rr"><i>✦</i> <span data-i18n="realRes">REAL RESULT</span></span>
  <div class="q"><span data-i18n="liveWhat">"I live what I teach."</span><small>— MISS BOLDT</small></div>
</div>
    <div class="reveal"><div class="kicker" data-i18n="proofK">Her own journey</div><h3 data-i18n="proofH">Proof that it <i>works</i></h3><p data-i18n="proofP">As a coach, this was her personal weight-loss transformation. Meal planning, simple exercise and a consistent mindset: the same path she now shares with others.</p></div>
  </div>
</div></section>
<!-- QUOTE -->
<section class="quote"><div class="wrap reveal">
  <div class="q">“</div>
  <div class="kicker" style="justify-content:center;color:#f1d8ea" data-i18n="k3">In her words</div>
  <blockquote data-i18n="quote">When I <span>sing</span> and <span>dance</span>, I channel healing vibrations to everyone around.</blockquote>
  <div class="who"><img src="<?php echo esc_url( MB_URI ); ?>/img/portrait.jpg" alt="Niomi Boldt (Miss Boldt), singer, dancer and wellness coach, smiling in a purple cap"><div><b>Niomi Boldt</b><small>SINGER · DANCER · HEALER</small></div></div>
</div></section>

<!-- TALKS -->
<section class="topics light" id="talks"><div class="wrap">
  <div class="head reveal">
    <div><div class="kicker" data-i18n="k2">Talks &amp; keynotes</div><h2 class="disp" data-i18n="h2talk">Talks that <span class="it orchid">heal</span></h2></div>
    <p data-i18n="ptalk">Six themes, each shaped to your event. Tap one to request it.</p>
  </div>
  <div class="tgrid">
    <button class="tile reveal" data-topic="Healing from trauma"><span class="num">01</span><span class="ic">♡</span><h3 data-i18n="t1">Healing from sexual &amp; emotional trauma</h3><p data-i18n="t1p">Its effects, and the way through.</p><span class="ask" data-i18n="ask">REQUEST THIS TALK →</span></button>
    <button class="tile reveal" data-topic="Healthy lifestyle"><span class="num">02</span><span class="ic">❦</span><h3 data-i18n="t2">Living a healthy lifestyle</h3><p data-i18n="t2p">Body, mind and soul in balance.</p><span class="ask" data-i18n="ask">REQUEST THIS TALK →</span></button>
    <button class="tile reveal" data-topic="Purpose in life"><span class="num">03</span><span class="ic">✦</span><h3 data-i18n="t3">Working on your purpose</h3><p data-i18n="t3p">Find it, and live it daily.</p><span class="ask" data-i18n="ask">REQUEST THIS TALK →</span></button>
    <button class="tile reveal" data-topic="Forgiveness & tolerance"><span class="num">04</span><span class="ic">☮</span><h3 data-i18n="t4">Forgiveness &amp; tolerance</h3><p data-i18n="t4p">Freedom for you and those around you.</p><span class="ask" data-i18n="ask">REQUEST THIS TALK →</span></button>
    <button class="tile reveal" data-topic="Accountability"><span class="num">05</span><span class="ic">⚖</span><h3 data-i18n="t5">Owning life's mistakes</h3><p data-i18n="t5p">Accountability that sets you free.</p><span class="ask" data-i18n="ask">REQUEST THIS TALK →</span></button>
    <button class="tile reveal" data-topic="Building a dream life"><span class="num">06</span><span class="ic">☀</span><h3 data-i18n="t6">Building a dream life</h3><p data-i18n="t6p">From vision to everyday steps.</p><span class="ask" data-i18n="ask">REQUEST THIS TALK →</span></button>
  </div>
  <div class="langrow reveal">
    <div><h4 class="disp" data-i18n="lgh">One voice,<br><span class="it sand">three languages</span></h4></div>
    <p data-i18n="lgp">Woven into everything she does, for cultural diversity and real connection.</p>
    <div class="langs">
      <div class="lg"><b>EN</b><small>English</small></div>
      <div class="lg"><b>DE</b><small>Deutsch</small></div>
      <div class="lg home"><b>AKAN</b><small><span class="flag"></span> <span data-i18n="mt">Twi · Fanti</span></small></div>
    </div>
  </div>
</div></section>

<!-- ROLES -->
<section class="roles" id="roles"><div class="wrap">
  <div class="head reveal">
    <div><div class="kicker" data-i18n="k5">Beyond the stage</div><h2 class="disp" data-i18n="h2roles">More than<br>a <span class="it gold">performer</span></h2></div>
    <p data-i18n="proles">One artist, many gifts. Tap any of them to enquire.</p>
  </div>
  <div class="rgrid">
    <button class="role hl reveal" data-role="Life coaching"><span class="ar">↗</span><span class="ri"><svg width="24" height="24" fill="none" stroke="currentColor" stroke-width="1.8"><circle cx="12" cy="8" r="4"/><path d="M4 21c1-5 5-7 8-7s7 2 8 7"/></svg></span><h3 data-i18n="r1">Personal life coach</h3><p data-i18n="r1p">One-to-one guidance to heal and grow.</p></button>
    <button class="role reveal" data-role="Speaking"><span class="ar">↗</span><span class="ri"><svg width="24" height="24" fill="none" stroke="currentColor" stroke-width="1.8"><rect x="9" y="3" width="6" height="11" rx="3"/><path d="M5 11a7 7 0 0014 0M12 18v3"/></svg></span><h3 data-i18n="r2">Speaker</h3><p data-i18n="r2p">Keynotes and talks that move people.</p></button>
    <button class="role reveal" data-role="Songwriting"><span class="ar">↗</span><span class="ri"><svg width="24" height="24" fill="none" stroke="currentColor" stroke-width="1.8"><path d="M9 18V5l11-2v13"/><circle cx="6" cy="18" r="3"/><circle cx="17" cy="16" r="3"/></svg></span><h3 data-i18n="r3">Singer-songwriter</h3><p data-i18n="r3p">Original songs with a healing message.</p></button>
    <button class="role reveal" data-role="Storytelling dance"><span class="ar">↗</span><span class="ri"><svg width="24" height="24" fill="none" stroke="currentColor" stroke-width="1.8"><circle cx="13" cy="4" r="2"/><path d="M6 10l5-2 4 3 4-2M11 8l-1 7-4 6M10 15l5 2 1 5"/></svg></span><h3 data-i18n="r4">Storytelling dancer</h3><p data-i18n="r4p">Stories told through body and movement.</p></button>
    <button class="role reveal" data-role="Author"><span class="ar">↗</span><span class="ri"><svg width="24" height="24" fill="none" stroke="currentColor" stroke-width="1.8"><path d="M3 5c3-1 6-1 9 1 3-2 6-2 9-1v14c-3-1-6-1-9 1-3-2-6-2-9-1z"/><path d="M12 6v14"/></svg></span><h3 data-i18n="r5">Author</h3><p data-i18n="r5p">Words on healing, purpose and life.</p></button>
    <button class="role reveal" data-role="Acting"><span class="ar">↗</span><span class="ri"><svg width="24" height="24" fill="none" stroke="currentColor" stroke-width="1.8"><rect x="3" y="7" width="14" height="12" rx="2"/><path d="M17 11l4-3v10l-4-3M3 7l3-4h5l-3 4"/></svg></span><h3 data-i18n="r6">Actress</h3><p data-i18n="r6p">Stage and screen roles.</p></button>
    <button class="role reveal" data-role="Modelling"><span class="ar">↗</span><span class="ri"><svg width="24" height="24" fill="none" stroke="currentColor" stroke-width="1.8"><rect x="3" y="6" width="18" height="14" rx="3"/><circle cx="12" cy="13" r="4"/><path d="M8 6l2-3h4l2 3"/></svg></span><h3 data-i18n="r7">Model</h3><p data-i18n="r7p">Photo, fashion and brand work.</p></button>
    <button class="role reveal" data-role="Event planning"><span class="ar">↗</span><span class="ri"><svg width="24" height="24" fill="none" stroke="currentColor" stroke-width="1.8"><rect x="3" y="5" width="18" height="16" rx="2"/><path d="M3 10h18M8 3v4M16 3v4M8 15l2.5 2.5L16 13"/></svg></span><h3 data-i18n="r8">Event planning assistant</h3><p data-i18n="r8p">Help bringing your event to life. <b style="color:var(--gold)">+ more</b></p></button>
  </div>
</div></section>

<section class="tests"><div class="wrap">
  <div class="head reveal"><div><div class="kicker" data-i18n="testK">Kind words</div><h2 class="disp" data-i18n="testH">What guests <span class="it orchid">say</span></h2></div><p data-i18n="testP">Sample quotes until real reviews arrive.</p></div>
  <div class="tgrid3"><?php $mb_x = mb_testimonial_cards(); if ( $mb_x ) { echo $mb_x; } else { ?>
    <div class="tcard reveal"><div class="qq">“</div><p>The whole room was singing and dancing by the end. Pure healing energy.</p><div class="by"><span><b>Event organiser</b>Wellness retreat</span><span class="smp" data-i18n="sample">SAMPLE</span></div></div>
    <div class="tcard reveal"><div class="qq">“</div><p>Her talk on forgiveness moved our students deeply. We will invite her again.</p><div class="by"><span><b>Teacher</b>School &amp; youth work</span><span class="smp" data-i18n="sample">SAMPLE</span></div></div>
    <div class="tcard reveal"><div class="qq">“</div><p>Warm, powerful and so easy to work with. Our guests still talk about it.</p><div class="by"><span><b>Host</b>Private celebration</span><span class="smp" data-i18n="sample">SAMPLE</span></div></div><?php } ?>
  </div>
</div></section>
<a class="nextp" href="<?php echo mb_url('book',''); ?>"><div class="wrap"><div><small data-i18n="nextK">NEXT PAGE</small><h3 class="disp" data-i18n="next3">Book <span class="it">now</span></h3></div><span class="arr">→</span></div></a>
<?php get_footer();
