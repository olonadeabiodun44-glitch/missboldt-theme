<!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
<meta charset="<?php bloginfo( 'charset' ); ?>">
<meta name="viewport" content="width=device-width, initial-scale=1">
<?php wp_head(); ?>
</head>
<body <?php body_class( 'loading' ); ?> data-page="<?php echo esc_attr( mb_page() ); ?>">
<?php wp_body_open(); ?>
<div id="loader"><div class="half t"></div><div class="half b"></div><div class="in"><div class="sig">Miss Boldt</div><div class="bar"><i></i></div><div class="pct">000</div></div></div>

<nav id="nav"><div class="wrap">
  <a class="logo" href="<?php echo mb_url('',''); ?>"><span class="mark">B</span><span><div class="name">Miss Boldt</div><div class="sub">ENTER~WELLNESS</div></span></a>
  <ul class="links">
    <li><a href="<?php echo mb_url('',''); ?>" data-nav="home" data-i18n="nHome">Home</a></li>
    <li><a href="<?php echo mb_url('live',''); ?>" data-nav="live" data-i18n="nLive">Live &amp; Music</a></li>
    <li><a href="<?php echo mb_url('about',''); ?>" data-nav="about" data-i18n="nAbout">About &amp; Talks</a></li>
    <li><a href="<?php echo mb_url('book','faq'); ?>" data-i18n="n5">FAQ</a></li>
  </ul>
  <div class="lang"><button class="on" data-lang="en">EN</button><button data-lang="de">DE</button><button data-lang="tw" title="Akan (Twi)">TWI</button></div>
  <a class="btn solid" href="<?php echo mb_url('book',''); ?>" data-nav="book" data-i18n="bookNow">Book now</a>
  <button class="burger" id="burger" aria-label="Open menu"><span></span></button>
</div></nav>

<div class="mmenu" id="mmenu">
  <div class="top"><a class="logo" href="<?php echo mb_url('',''); ?>"><span class="mark">B</span><span><div class="name">Miss Boldt</div><div class="sub">ENTER~WELLNESS</div></span></a><button class="x" id="mclose" aria-label="Close menu">✕</button></div>
  <ul>
    <li><a href="<?php echo mb_url('',''); ?>" data-nav="home"><span data-i18n="nHome">Home</span><i>01</i></a></li>
    <li><a href="<?php echo mb_url('live',''); ?>" data-nav="live"><span data-i18n="nLive">Live &amp; Music</span><i>02</i></a></li>
    <li><a href="<?php echo mb_url('about',''); ?>" data-nav="about"><span data-i18n="nAbout">About &amp; Talks</span><i>03</i></a></li>
    <li><a href="<?php echo mb_url('book',''); ?>" data-nav="book"><span data-i18n="nBook">Book</span><i>04</i></a></li>
  </ul>
  <div class="bottom"><div class="lang"><button class="on" data-lang="en">EN</button><button data-lang="de">DE</button><button data-lang="tw" title="Akan (Twi)">TWI</button></div><a class="btn solid" href="<?php echo mb_url('book',''); ?>" data-i18n="bookNow">Book now</a></div>
</div>
