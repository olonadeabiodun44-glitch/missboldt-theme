(()=>{
const RM=matchMedia('(prefers-reduced-motion: reduce)').matches;
const $=s=>document.querySelector(s),$$=s=>[...document.querySelectorAll(s)];
const loader=$('#loader');
if(RM){loader&&loader.remove();document.body.classList.remove('loading');return}
const desk=matchMedia('(hover:hover) and (min-width:901px)').matches;

/* ---------- loader ---------- */
(()=>{let seen=false;try{seen=sessionStorage.getItem('mb_seen')==='1';sessionStorage.setItem('mb_seen','1')}catch(e){}
 if(seen){loader.querySelector('.in').style.display='none';requestAnimationFrame(()=>{loader.classList.add('go');document.body.classList.remove('loading');setTimeout(()=>loader.classList.add('gone'),1200)});return}
 const bar=$('#loader .bar i'),pct=$('#loader .pct');let p=0;const t0=performance.now();
 const step=()=>{const e=performance.now()-t0;p=Math.min(100,Math.round(e/16));bar.style.width=p+'%';pct.textContent=String(p).padStart(3,'0');
  if(p<100)requestAnimationFrame(step);else{loader.classList.add('go');setTimeout(()=>document.body.classList.remove('loading'),250);setTimeout(()=>loader.classList.add('gone'),1300)}};
 requestAnimationFrame(step)})();

/* ---------- split headings into words ---------- */
const SEL='.head h2,.about h2,.stages h2,.faq h2,.cta h2,.fullbar h3,.langrow h4,.teaser h2,.phero h1,.nextp h3';
function split(el){
  if(el.dataset.split===el.innerHTML)return;let i=0;
  const walk=n=>{[...n.childNodes].forEach(c=>{
    if(c.nodeType===3){const parts=c.textContent.split(/(\s+)/);const f=document.createDocumentFragment();
      parts.forEach(p=>{if(!p)return;if(/^\s+$/.test(p)){f.appendChild(document.createTextNode(p));return}
        const w=document.createElement('span');w.className='w';const wi=document.createElement('span');wi.className='wi';wi.style.setProperty('--i',i++);wi.textContent=p;w.appendChild(wi);f.appendChild(w)});
      c.replaceWith(f)}
    else if(c.nodeType===1&&c.tagName!=='BR'&&!c.classList.contains('w'))walk(c)})};
  walk(el);el.dataset.split=el.innerHTML}
const sio=new IntersectionObserver(es=>es.forEach(e=>{if(e.isIntersecting){e.target.classList.add('split-in');sio.unobserve(e.target)}}),{threshold:.3});
const splitAll=instant=>$$(SEL).forEach(el=>{split(el);if(instant&&el.classList.contains('split-in'))return;sio.observe(el)});
splitAll();
$$('[data-lang]').forEach(b=>b.addEventListener('click',()=>setTimeout(()=>$$(SEL).forEach(el=>{const was=el.classList.contains('split-in');el.classList.remove('split-in');delete el.dataset.split;split(el);requestAnimationFrame(()=>requestAnimationFrame(()=>{if(was)el.classList.add('split-in');else sio.observe(el)}))}),0)));

/* ---------- image wipes ---------- */
$$('.card .img,.pic,.reel,.gi,.teaser .ph').forEach(e=>e.setAttribute('data-wipe',''));
$$('.stages .ph').forEach(e=>e.setAttribute('data-wipe','flat'));
const wio=new IntersectionObserver(es=>es.forEach(e=>{if(e.isIntersecting){e.target._w.forEach(x=>x.classList.add('wiped'));wio.unobserve(e.target)}}),{threshold:.1});
$$('[data-wipe]').forEach(e=>{const p=e.parentElement;(p._w=p._w||[]).push(e);wio.observe(p)});

/* ---------- count up ---------- */
const cio=new IntersectionObserver(es=>es.forEach(e=>{if(!e.isIntersecting)return;cio.unobserve(e.target);const n=e.target.firstChild,to=+n.textContent;let s=null;
  const f=t=>{s??=t;const k=Math.min(1,(t-s)/1200);n.textContent=Math.round(to*(1-Math.pow(1-k,3)));if(k<1)requestAnimationFrame(f)};requestAnimationFrame(f)}),{threshold:.6});
$$('.stats b,.big500 b,.statline b').forEach(b=>{if(b.firstChild&&/^\d+$/.test(b.firstChild.textContent))cio.observe(b)});

/* ---------- orbs ---------- */
[['.media','#7c1c63','60%','5%'],['.shows','#b05aa6','5%','40%'],['.teaser','#f2b84b','70%','60%'],['.roles','#b05aa6','70%','15%'],['.watch','#f2b84b','15%','30%'],['.faq','#7c1c63','80%','60%'],['.about','#f2b84b','60%','70%']].forEach(([s,c,x,y],i)=>{const sec=$(s);if(!sec)return;const o=document.createElement('div');o.className='orb';o.style.cssText=`width:420px;height:420px;background:${c};left:${x};top:${y};animation-delay:-${i*3}s`;sec.prepend(o)});

/* ---------- tilt + glare ---------- */
if(desk)$$('.role,.reel,.card .img,.tile,.cal,.tcard').forEach(el=>{el.classList.add('tilt');const g=document.createElement('span');g.className='glare';el.appendChild(g);const max=el.classList.contains('cal')?4:9;
  el.addEventListener('mousemove',e=>{const r=el.getBoundingClientRect(),x=(e.clientX-r.left)/r.width,y=(e.clientY-r.top)/r.height;
    el.style.transform=`perspective(900px) rotateX(${(.5-y)*max}deg) rotateY(${(x-.5)*max}deg) translateZ(0)`;el.style.setProperty('--gx',x*100+'%');el.style.setProperty('--gy',y*100+'%')});
  el.addEventListener('mouseleave',()=>{el.style.transform=''})});

/* ---------- magnetic buttons ---------- */
if(desk)$$('.btn,.arrow,.play,.nb').forEach(b=>{b.addEventListener('mousemove',e=>{const r=b.getBoundingClientRect();b.style.transform=`translate(${(e.clientX-r.left-r.width/2)*.25}px,${(e.clientY-r.top-r.height/2)*.35}px)`});b.addEventListener('mouseleave',()=>b.style.transform='')});

/* ---------- cursor ---------- */
let mx=innerWidth/2,my=innerHeight/2;
if(desk){document.body.classList.add('has-cur');const c=document.createElement('div'),d=document.createElement('div');c.className='cur';d.className='cur-dot';document.body.append(c,d);let cx=mx,cy=my;
  addEventListener('mousemove',e=>{mx=e.clientX;my=e.clientY;d.style.transform=`translate(${mx-3}px,${my-3}px)`});
  const loop=()=>{cx+=(mx-cx)*.18;cy+=(my-cy)*.18;c.style.transform=`translate(${cx+16}px,${cy+18}px) translate(-50%,-50%)`;requestAnimationFrame(loop)};loop();
  d.style.translate='0 0';d.style.left='0';d.style.top='0';d.style.transform='';c.style.left='0';c.style.top='0';
  const lab=el=>el.closest('.reel,[data-video]')?'PLAY':el.closest('.card,[data-pick]')?'BOOK':el.closest('.role,.tile')?'ASK':el.closest('.days .o')?'PICK':'';
  addEventListener('mouseover',e=>{const t=e.target;const L=lab(t);c.textContent=L;c.classList.toggle('big',!!L);
    c.style.width=c.style.height=(!L&&t.closest('a,button,input,select,textarea'))?'48px':''});
  document.addEventListener('mouseleave',()=>{c.classList.add('hide');d.classList.add('hide')});document.addEventListener('mouseenter',()=>{c.classList.remove('hide');d.classList.remove('hide')})}

/* ---------- hero parallax ---------- */
const vis=$('#visual'),hero=$('.hero');
if(desk&&hero&&vis)hero.addEventListener('mousemove',e=>{vis.style.setProperty('--mx',(e.clientX/innerWidth-.5)*2);vis.style.setProperty('--my',(e.clientY/innerHeight-.5)*2)});

/* ---------- progress, velocity, marquee ---------- */
const prog=document.createElement('div');prog.id='prog';document.body.appendChild(prog);
const tracks=$$('.mtrack');let mqx=0,dir=1,lastY=scrollY,vel=0,sv=0;
/* ---------- bubbles ---------- */
const bc=document.createElement('canvas');bc.id='bubbles';const sc=document.createElement('canvas');sc.id='shatter';document.body.append(bc,sc);
const bx=bc.getContext('2d'),sx=sc.getContext('2d');let W,H,DPR=Math.min(2,devicePixelRatio||1);
const size=()=>{W=innerWidth;H=innerHeight;[bc,sc].forEach(c=>{c.width=W*DPR;c.height=H*DPR});bx.setTransform(DPR,0,0,DPR,0,0);sx.setTransform(DPR,0,0,DPR,0,0)};size();addEventListener('resize',size);
const NB=desk?9:5,bubbles=[];
const mk=(b,init)=>{b.r=8+Math.random()*(desk?20:14);b.x=Math.random()*W;b.y=init?Math.random()*H:H+b.r+Math.random()*80;b.vy=-(.12+Math.random()*.25);b.ph=Math.random()*6.28;b.hue=Math.random()*360;b.z=.4+Math.random()*.9;b.px=0;b.py=0;return b};
for(let i=0;i<NB;i++)bubbles.push(mk({},true));
function drawBubble(b){const x=b.x+b.px,y=b.y+b.py,r=b.r;
  const g=bx.createRadialGradient(x-r*.3,y-r*.35,r*.1,x,y,r);g.addColorStop(0,'rgba(255,255,255,0.02)');g.addColorStop(.75,`hsla(${b.hue},90%,70%,0.05)`);g.addColorStop(1,`hsla(${b.hue+60},95%,72%,0.32)`);
  bx.fillStyle=g;bx.beginPath();bx.arc(x,y,r,0,6.283);bx.fill();
  const lg=bx.createLinearGradient(x-r,y-r,x+r,y+r);lg.addColorStop(0,`hsla(${b.hue},100%,75%,.65)`);lg.addColorStop(.5,`hsla(${b.hue+90},100%,70%,.35)`);lg.addColorStop(1,`hsla(${b.hue+180},100%,72%,.65)`);
  bx.strokeStyle=lg;bx.lineWidth=1.2;bx.stroke();
  bx.fillStyle='rgba(255,255,255,.55)';bx.beginPath();bx.ellipse(x-r*.38,y-r*.42,r*.22,r*.1,-.7,0,6.283);bx.fill()}
addEventListener('pointerdown',e=>{for(let i=bubbles.length-1;i>=0;i--){const b=bubbles[i],dx=e.clientX-(b.x+b.px),dy=e.clientY-(b.y+b.py);if(dx*dx+dy*dy<b.r*b.r*1.3){
  for(let k=0;k<12;k++){const p=document.createElement('i');p.className='pop';const a=k/12*6.283,dist=b.r+20+Math.random()*30;p.style.cssText=`left:${e.clientX-4}px;top:${e.clientY-4}px;--dx:${Math.cos(a)*dist}px;--dy:${Math.sin(a)*dist}px;background:hsl(${b.hue+k*30},95%,70%)`;document.body.appendChild(p);setTimeout(()=>p.remove(),720)}
  mk(b,false);break}}},{passive:true});

/* ---------- shatter (broken screen) ---------- */
const PAL=['255,46,150','40,230,255','242,184,75','176,90,166','255,255,255','124,28,99'];
let shards=[],cracks=[],shI=0,lastBurst=-1e9,lastInput=-1e9,shDone=false;try{shDone=sessionStorage.getItem('mb_shat')==='1'}catch(e){}if(shDone)sc.remove();
['wheel','touchmove','keydown'].forEach(ev=>addEventListener(ev,()=>{lastInput=performance.now()},{passive:true}));
function newCrack(){const cx=W*(.2+Math.random()*.6),cy=H*(.2+Math.random()*.6),rays=10+Math.floor(Math.random()*5),rings=[0,50,120,230,380,600,900,1400];
  const ang=[];for(let i=0;i<rays;i++)ang.push(i/rays*6.283+(Math.random()-.5)*.35);
  const P=rings.map((R,ri)=>ang.map(a=>{const rr=ri?R*(.75+Math.random()*.5):0,aa=a+(Math.random()-.5)*.18;return[cx+Math.cos(aa)*rr,cy+Math.sin(aa)*rr,Math.cos(a),Math.sin(a)]}));
  shards=[];cracks=[];
  for(let ri=0;ri<rings.length-1;ri++)for(let a=0;a<rays;a++){const b=(a+1)%rays,q=[P[ri][a],P[ri][b],P[ri+1][b],P[ri+1][a]];
    shards.push({q,c:PAL[Math.floor(Math.random()*PAL.length)],al:Math.random()<.45?Math.random()*.3:0,d:(ri+1)*(2+Math.random()*3),dx:Math.cos(ang[a]),dy:Math.sin(ang[a])});
    cracks.push([P[ri][a],P[ri+1][a]]);if(ri>0&&Math.random()<.75)cracks.push([P[ri][a],P[ri][b]])}}
function drawShatter(I){sx.clearRect(0,0,W,H);if(I<.01)return;
  shards.forEach(s=>{if(!s.al)return;const o=s.d*I;sx.fillStyle=`rgba(${s.c},${s.al*I})`;sx.beginPath();s.q.forEach((p,i)=>{const x=p[0]+s.dx*o,y=p[1]+s.dy*o;i?sx.lineTo(x,y):sx.moveTo(x,y)});sx.closePath();sx.fill()});
  [['255,40,140',2.5],['40,230,255',-2.5],['255,255,255',0]].forEach(([c,off])=>{sx.strokeStyle=`rgba(${c},${(off?.45:.7)*I})`;sx.lineWidth=off?1:1.2;sx.beginPath();cracks.forEach(([a,b])=>{sx.moveTo(a[0]+off,a[1]);sx.lineTo(b[0]+off,b[1])});sx.stroke()})}

/* ---------- main loop ---------- */
const root=document.documentElement;let tw=0;
function frame(t){
  const y=scrollY,dy=y-lastY;lastY=y;if(dy)dir=dy>0?1:-1;
  vel+=(dy-vel)*.25;sv=Math.abs(vel);
  // progress
  prog.style.transform=`scaleX(${y/Math.max(1,document.documentElement.scrollHeight-innerHeight)})`;
  // chromatic
  const g=shI>.02?Math.max(-9,Math.min(9,vel*.18))*shI:0;root.style.setProperty('--g',g.toFixed(2));
  // shatter: only a short burst right after real user scrolling, always fades out
  const now=performance.now(),userActive=now-lastInput<220;
  if(userActive&&sv>16&&!shDone){newCrack();lastBurst=now;shDone=true;try{sessionStorage.setItem('mb_shat','1')}catch(e){}}
  const age=now-lastBurst;shI=age<160?age/160:Math.max(0,1-(age-160)/650);if(shDone&&age>900&&sc.isConnected){sc.remove();document.body.classList.remove('fxg')}
  root.style.setProperty('--ga',shI.toFixed(3));document.body.classList.toggle('fxg',shI>.03);
  drawShatter(shI);
  // marquee
  if(tracks.length){tw=tw||tracks[0].offsetWidth;mqx-=(1+sv*.35)*dir;if(mqx<=-tw)mqx+=tw;if(mqx>0)mqx-=tw;tracks.forEach(tr=>tr.style.transform=`translate3d(${mqx}px,0,0)`)}
  // bubbles
  bx.clearRect(0,0,W,H);
  bubbles.forEach(b=>{b.ph+=.012;b.y+=b.vy*b.z-((performance.now()-lastInput<300)?vel:0)*.35*b.z;b.x+=Math.sin(b.ph)*.35;b.hue+=.3;
    const dx=b.x-mx,dy2=b.y-my,dd=Math.hypot(dx,dy2);if(dd<90){const f=(90-dd)/90*14;b.px+=((dx/dd||0)*f-b.px)*.1;b.py+=((dy2/dd||0)*f-b.py)*.1}else{b.px*=.94;b.py*=.94}
    if(b.y<-b.r-60)mk(b,false);else if(b.y>H+b.r+220){mk(b,false);b.y=-b.r-20}
    drawBubble(b)});
  requestAnimationFrame(frame)}
addEventListener('resize',()=>{tw=0});
requestAnimationFrame(frame);
addEventListener('touchmove',e=>{const t=e.touches[0];mx=t.clientX;my=t.clientY},{passive:true});
})();
