(()=>{
const $=s=>document.querySelector(s),$$=s=>[...document.querySelectorAll(s)];
const store={get(k){try{return sessionStorage.getItem(k)}catch(e){return null}},set(k,v){try{sessionStorage.setItem(k,v)}catch(e){}},del(k){try{sessionStorage.removeItem(k)}catch(e){}}};
let lang='en';
const CFG=window.MB_CFG||null;
const EMAIL=(CFG&&CFG.email)||'niomiboldt@gmail.com';
const T=(en,de)=>lang==='de'?de:en;
const toast=m=>{const t=$('#toast');if(!t)return;t.textContent=m;t.classList.add('show');clearTimeout(t._t);t._t=setTimeout(()=>t.classList.remove('show'),2600)};
window.MB={toast,store,T,get lang(){return lang}};

/* ---------- current page in nav ---------- */
const page=document.body.dataset.page;
$$(`[data-nav="${page}"]`).forEach(a=>a.classList.add('cur-page'));

/* ---------- page transitions ---------- */
const curtain=document.createElement('div');curtain.id='curtain';curtain.innerHTML='<i></i><i></i>';document.body.appendChild(curtain);
const RM=matchMedia('(prefers-reduced-motion: reduce)').matches;
document.addEventListener('click',e=>{const a=e.target.closest('a[href]');if(!a||e.defaultPrevented||e.metaKey||e.ctrlKey||a.target==='_blank')return;
  if(CFG){let u;try{u=new URL(a.href,location.href)}catch(_){return}
    if(u.origin!==location.origin||/\/wp-(admin|login)/.test(u.pathname)||/\.[a-z0-9]{2,4}$/i.test(u.pathname)||a.hasAttribute('data-modal'))return;
    if(u.pathname===location.pathname){if(u.hash){const t=document.getElementById(u.hash.slice(1));if(t){e.preventDefault();t.scrollIntoView({behavior:'smooth'})}}return}
    e.preventDefault();if(RM){location.href=u.href;return}curtain.classList.add('on');setTimeout(()=>location.href=u.href,520);return}
  const h=a.getAttribute('href');if(!/^(\/|\/?[a-z-]+(\.html)?)(#[\w-]+)?$/.test(h))return;
  const norm=p=>{p=(p||'').replace(/^\//,'').replace(/\.html$/,'');return p===''||p==='index'?'index':p};
  const [file,hash]=h.split('#');if(norm(file)===norm(location.pathname.split('/').pop())){if(hash){e.preventDefault();document.getElementById(hash)?.scrollIntoView({behavior:'smooth'})}return}
  e.preventDefault();if(hash)store.set('mb_hash',hash);
  if(RM){location.href=file;return}
  curtain.classList.add('on');setTimeout(()=>location.href=file,520)});
addEventListener('pageshow',()=>curtain.classList.remove('on'));
/* ---------- single-page mode (preview link) ---------- */
const SPA=document.body.dataset.spa==='1';
let showView=null;
if(SPA){
  const views=$$('.view'),R={};views.forEach(v=>R[v.dataset.route]=v);
  const setNav=p=>{document.body.dataset.page=p;$$('[data-nav]').forEach(a=>a.classList.toggle('cur-page',a.dataset.nav===p))};
  showView=(hash,animate)=>{let v=R[hash],target=null;if(!v&&hash){target=document.getElementById(hash);v=target&&target.closest('.view')}if(!v)v=R.home;
    const swap=()=>{const changed=v.hidden;views.forEach(x=>x.hidden=x!==v);setNav(v.dataset.view);
      if(target)setTimeout(()=>target.scrollIntoView({behavior:changed?'instant':'smooth'}),changed?80:0);else if(changed)scrollTo({top:0,behavior:'instant'});
      dispatchEvent(new Event('scroll'))};
    if(animate&&v.hidden&&!RM){curtain.classList.add('on');setTimeout(()=>{swap();setTimeout(()=>curtain.classList.remove('on'),120)},560)}else swap()};
  const goHash=h=>{if(location.hash==='#'+h)showView(h,true);else location.hash=h};
  window.MB.go=goHash;
  addEventListener('hashchange',()=>showView(location.hash.slice(1),true));
  document.addEventListener('click',e=>{const a=e.target.closest('a[href^="#"]');if(!a||a.dataset.modal!==undefined)return;const hh=a.getAttribute('href').slice(1);if(!hh)return;e.preventDefault();goHash(hh)});
  showView(location.hash.slice(1),false);
}

const pendingHash=store.get('mb_hash');if(pendingHash){store.del('mb_hash');setTimeout(()=>document.getElementById(pendingHash)?.scrollIntoView({behavior:'smooth'}),900)}

/* ---------- nav ---------- */
const nav=$('#nav'),totop=$('#totop');
const mcta=$('#mcta');
addEventListener('scroll',()=>{nav.classList.toggle('scrolled',scrollY>40);mcta&&mcta.classList.toggle('show',scrollY>500&&(innerHeight+scrollY)<document.body.scrollHeight-260);totop&&totop.classList.toggle('show',scrollY>900)},{passive:true});
totop&&(totop.onclick=()=>scrollTo({top:0,behavior:'smooth'}));
const mm=$('#mmenu');
$('#burger').onclick=()=>{mm.classList.add('open');document.body.classList.add('lock')};
const closeMenu=()=>{mm.classList.remove('open');document.body.classList.remove('lock')};
$('#mclose').onclick=closeMenu;
mm.querySelectorAll('a').forEach(a=>a.addEventListener('click',closeMenu));

/* ---------- reveal ---------- */
const io=new IntersectionObserver(es=>es.forEach(e=>{if(e.isIntersecting){e.target.classList.add('in');io.unobserve(e.target)}}),{threshold:.12});
$$('.reveal').forEach(el=>io.observe(el));

/* ---------- modals ---------- */
const openM=m=>{m.classList.add('open');document.body.classList.add('lock')};
const closeM=()=>{$$('.modal,.lb').forEach(m=>m.classList.remove('open'));document.body.classList.remove('lock');typeof stopVid==='function'&&stopVid()};
const vbox=$('#vmodal .vid'),vdef=vbox?vbox.innerHTML:'';
const stopVid=()=>{if(vbox&&vbox.dataset.live){vbox.innerHTML=vdef;delete vbox.dataset.live}};
$$('[data-video]').forEach(b=>b.addEventListener('click',()=>{
  const yt=b.dataset.yt,mp4=b.dataset.mp4,title=b.dataset.title||b.querySelector('h3')?.textContent||'Live at the café';
  if(yt||mp4){vbox.dataset.live=1;vbox.innerHTML=yt?`<iframe src="https://www.youtube-nocookie.com/embed/${encodeURIComponent(yt)}?autoplay=1&rel=0" title="${title.replace(/"/g,'')}" allow="autoplay; encrypted-media; picture-in-picture; fullscreen" allowfullscreen style="position:absolute;inset:0;width:100%;height:100%;border:0"></iframe>`:`<video src="${mp4}" controls autoplay playsinline style="position:absolute;inset:0;width:100%;height:100%;background:#000"></video>`}
  else{stopVid();const img=b.querySelector('img')||$('#slides img:nth-child(2)')||$('img');$('#vimg').src=img.src;$('#vtitle').textContent=title}
  openM($('#vmodal'))}));
$$('[data-modal]').forEach(a=>a.addEventListener('click',e=>{e.preventDefault();openM($('#lmodal'))}));
$$('[data-close]').forEach(b=>b.addEventListener('click',closeM));
$$('.modal').forEach(m=>m.addEventListener('click',e=>{if(e.target===m)closeM()}));
addEventListener('keydown',e=>{if(e.key==='Escape'){closeM();closeMenu()}});

/* ---------- FAQ ---------- */
$$('.qi button').forEach(b=>b.addEventListener('click',()=>{const q=b.parentElement,o=q.classList.contains('open');$$('.qi').forEach(x=>x.classList.remove('open'));if(!o)q.classList.add('open')}));

/* ---------- copy ---------- */
const copy=async(txt,msg)=>{try{await navigator.clipboard.writeText(txt);toast(msg)}catch(e){toast(txt)}};
$$('#copyMail').forEach(b=>b.onclick=e=>{e.preventDefault();e.stopPropagation();copy(EMAIL,T('Email address copied','E-Mail-Adresse kopiert'))});

/* ---------- picks: send choices to the booking page ---------- */
const XN={talk:'Wellness talk',sing:'Live singing',dance:'Storytelling dance',full:'The full experience (3 in 1)'};
const isBook=page==='book';
function addPick(kind,val,label){
  if(SPA){applyPick(kind,val);toast(T('Added to your request: ','Hinzugefügt: ')+label);window.MB.go('book');return}
  if(isBook){applyPick(kind,val);toast(T('Added to your request: ','Hinzugefügt: ')+label);document.getElementById('book').scrollIntoView({behavior:'smooth'});return}
  let p=[];try{p=JSON.parse(store.get('mb_picks')||'[]')}catch(e){}p.push([kind,val]);store.set('mb_picks',JSON.stringify(p));store.set('mb_toast',label);
  curtain.classList.add('on');setTimeout(()=>location.href=(CFG&&CFG.book)||'book.html',520)}
$$('[data-pick]').forEach(b=>b.addEventListener('click',()=>addPick('x',b.dataset.pick,XN[b.dataset.pick])));
$$('[data-topic]').forEach(b=>b.addEventListener('click',()=>addPick('topic',b.dataset.topic,b.dataset.topic)));
$$('[data-role]').forEach(b=>b.addEventListener('click',()=>addPick('role',b.dataset.role,b.dataset.role)));
$$('[data-method]').forEach(b=>b.addEventListener('click',()=>{b.classList.add('added');addPick('method',b.dataset.method,b.dataset.method)}));
function applyPick(kind,val){
  if(kind==='x'){$(`#xgrid [data-v="${val}"]`)?.classList.add('on');$('#fldX')?.classList.remove('err')}
  if(kind==='topic'){$$('#topics .opt').forEach(o=>{if(o.textContent===val)o.classList.add('on')});$('#xgrid [data-v="talk"]')?.classList.add('on')}
  if(kind==='role'){$$('#extras .opt').forEach(o=>{if(o.textContent===val)o.classList.add('on')})}
  if(kind==='method'){$$('#methods .opt').forEach(o=>{if(o.textContent===val)o.classList.add('on')})}}

/* ---------- hero slider (home) ---------- */
if($('#slides')){
const slides=$$('#slides img');let si=0,st;
const go=n=>{si=(n+slides.length)%slides.length;slides.forEach((s,i)=>s.classList.toggle('on',i===si));$('#counter').innerHTML=String(si+1).padStart(2,'0')+' <span>/ 03</span>';$('#slab').textContent=slides[si].dataset.cap;restart()};
const restart=()=>{clearInterval(st);st=setInterval(()=>go(si+1),6000)};
$('#prev').onclick=()=>go(si-1);$('#next').onclick=()=>go(si+1);restart();
}

/* ---------- audio players (real audio when a file is set, otherwise "coming soon") ---------- */
const SOON=()=>T('Music coming soon: Miss Boldt\'s recordings will play here.','Musik folgt bald: Hier laufen bald Miss Boldts Aufnahmen.');
function makePlayer({wave,btn,timeEl,box,line,src,onToggle}){
  let bars=[],audio=null,playing=false;const N=110;
  if(wave){let seed=7;for(let i=0;i<N;i++){seed=(seed*9301+49297)%233280;const b=document.createElement('i');b.style.height=(10+Math.abs(Math.sin(i*.35))*22+(seed/233280)*16)+'px';wave.appendChild(b);bars.push(b)}}
  const fmt=s=>isFinite(s)?Math.floor(s/60)+':'+String(Math.floor(s%60)).padStart(2,'0'):'0:00';
  const draw=()=>{const d=audio&&audio.duration||0,p=audio?audio.currentTime:0,k=d?p/d:0;bars.forEach((b,i)=>b.classList.toggle('on',i<k*N));if(line)line.style.width=k*100+'%';if(timeEl)timeEl.textContent=audio?fmt(p)+' / '+fmt(d):T('Coming soon','Bald verfügbar')};
  const setSrc=s=>{if(audio){audio.pause();audio=null}playing=false;box&&box.classList.remove('playing');box&&box.classList.toggle('soon',!s);
    if(s){audio=new Audio(s);audio.preload='metadata';audio.addEventListener('timeupdate',draw);audio.addEventListener('loadedmetadata',draw);
      audio.addEventListener('ended',()=>{playing=false;box&&box.classList.remove('playing');onToggle&&onToggle(false);audio.currentTime=0;draw()});
      audio.addEventListener('error',()=>{setSrc(null);toast(SOON())})}
    draw()};
  btn.addEventListener('click',async()=>{if(!audio){toast(SOON());return}
    if(playing){audio.pause();playing=false}else{try{await audio.play();playing=true}catch(e){toast(T('Tap play again to start the music.','Nochmal tippen, um die Musik zu starten.'))}}
    box&&box.classList.toggle('playing',playing);onToggle&&onToggle(playing)});
  const seekEl=wave||line?.parentElement;seekEl&&seekEl.addEventListener('click',e=>{if(!audio||!audio.duration)return;const r=seekEl.getBoundingClientRect();audio.currentTime=Math.max(0,Math.min(1,(e.clientX-r.left)/r.width))*audio.duration;draw()});
  setSrc(src);return{setSrc,get playing(){return playing}}}
if($('#playBtn'))makePlayer({wave:$('#wave'),btn:$('#playBtn'),timeEl:$('#time'),box:$('#player'),src:$('#player').dataset.src||null});

/* ---------- music page ---------- */
if($('#tracks')){
  const vin=$('#vinyl'),tr=$$('.track');let cur=0;
  const mp=makePlayer({btn:$('#mPlay'),timeEl:$('#mTime'),box:$('#mbox'),line:$('#mLine'),src:tr[0].dataset.src||null,onToggle:p=>{vin.classList.toggle('playing',p);tr.forEach((t,i)=>t.classList.toggle('playing',p&&i===cur))}});
  const pick=i=>{cur=i;tr.forEach((t,j)=>t.classList.toggle('on',j===i));$('#mTitle').textContent=tr[i].querySelector('b').textContent;mp.setSrc(tr[i].dataset.src||null);vin.classList.remove('playing');tr.forEach(t=>t.classList.remove('playing'))};
  tr.forEach((t,i)=>t.addEventListener('click',()=>{if(i!==cur)pick(i);$('#mPlay').click()}));
  pick(0);
}

/* ---------- before / after slider ---------- */
$$('.ba').forEach(ba=>{const r=ba.querySelector('input');const set=v=>ba.style.setProperty('--p',v+'%');r.addEventListener('input',()=>set(r.value));
  let shown=false;new IntersectionObserver(es=>{if(es[0].isIntersecting&&!shown){shown=true;let v=50,t0=performance.now();const f=t=>{const k=Math.min(1,(t-t0)/1600);v=50+Math.sin(k*Math.PI*2)*28*(1-k);set(v);r.value=v;if(k<1)requestAnimationFrame(f)};requestAnimationFrame(f)}},{threshold:.5}).observe(ba)});

/* ---------- video filters ---------- */
if($('#filters')){const rs=$$('#vwall .reel');$$('#filters button').forEach(b=>{const f=b.dataset.f,n=f==='all'?rs.length:rs.filter(r=>r.dataset.cat===f).length;const s=b.querySelector('span');if(s)s.textContent=String(n).padStart(2,'0');if(f!=='all'&&!n)b.style.display='none'});$$('#filters button').forEach(b=>b.addEventListener('click',()=>{$$('#filters button').forEach(x=>x.classList.toggle('on',x===b));const f=b.dataset.f;
  $$('#vwall .reel').forEach(r=>{const show=f==='all'||r.dataset.cat===f;r.classList.toggle('hide',!show);if(show){r.classList.remove('in');requestAnimationFrame(()=>requestAnimationFrame(()=>r.classList.add('in','wiped')))}})}))}
$('#uploadBtn')&&($('#uploadBtn').onclick=()=>toast(T('Send your videos or links to Olonade, and they will appear here.','Schick deine Videos oder Links an Olonade, dann erscheinen sie hier.')));

/* ---------- gallery lightbox ---------- */
if($('#ggrid')){const items=$$('#ggrid .gi'),lb=$('#lb');let gi=0;
  const show=i=>{gi=(i+items.length)%items.length;const im=items[gi].querySelector('img');$('#lbImg').src=im.src;$('#lbCap').textContent=im.alt};
  items.forEach((it,i)=>it.addEventListener('click',()=>{show(i);lb.classList.add('open');document.body.classList.add('lock')}));
  $('#lbPrev').onclick=()=>show(gi-1);$('#lbNext').onclick=()=>show(gi+1);$('#lbX').onclick=closeM;
  lb.addEventListener('click',e=>{if(e.target===lb)closeM()});
  addEventListener('keydown',e=>{if(!lb.classList.contains('open'))return;if(e.key==='ArrowLeft')show(gi-1);if(e.key==='ArrowRight')show(gi+1)})}

/* ---------- timeline tabs ---------- */
$$('.tabs2 button').forEach(b=>b.addEventListener('click',()=>{$$('.tabs2 button').forEach(x=>x.classList.toggle('on',x===b));$$('.tl').forEach(t=>t.classList.toggle('on',t.id===b.dataset.t))}));

/* ---------- calendar + form (book page) ---------- */
let renderCal=()=>{};
if($('#form')){
const today=new Date();today.setHours(0,0,0,0);
const start=new Date(today.getFullYear(),today.getMonth(),1);
let view=new Date(start),sel=null;
// sample booked dates (replace with Miss Boldt's real calendar)
const bookedSet=new Set();
if(CFG&&Array.isArray(CFG.booked)){CFG.booked.forEach(s=>{const[y,m,d]=s.split('-').map(Number);if(y)bookedSet.add(new Date(y,m-1,d).toDateString())})}
else for(let m=0;m<14;m++){const d=new Date(start.getFullYear(),start.getMonth()+m,1);[5,6,19,24,25,26].forEach((x,i)=>{if((m+i)%3!==1)bookedSet.add(new Date(d.getFullYear(),d.getMonth(),x).toDateString())})}
const MN={en:['January','February','March','April','May','June','July','August','September','October','November','December'],de:['Januar','Februar','März','April','Mai','Juni','Juli','August','September','Oktober','November','Dezember'],tw:['Ɔpɛpɔn','Ɔgyefoɔ','Ɔbɛnem','Oforisuo','Kotonimma','Ayɛwohomumu','Kutawonsa','Ɔsanaa','Ɛbɔ','Ahinime','Obubuo','Ɔpɛnimma']};
const DN={en:['Mo','Tu','We','Th','Fr','Sa','Su'],de:['Mo','Di','Mi','Do','Fr','Sa','So'],tw:['Dw','Be','Wu','Ya','Fi','Me','Kw']};
const iso=d=>d.getFullYear()+'-'+String(d.getMonth()+1).padStart(2,'0')+'-'+String(d.getDate()).padStart(2,'0');
renderCal=function(){
  const y=view.getFullYear(),m=view.getMonth(),days=$('#days');
  $('#calTitle').textContent=MN[lang][m]+' '+y;
  $('#calPrev').disabled=view<=start;
  $('#calNext').disabled=(y-start.getFullYear())*12+m-start.getMonth()>=12;
  days.innerHTML=DN[lang].map(d=>`<span class="h">${d}</span>`).join('');
  const off=(new Date(y,m,1).getDay()+6)%7;for(let i=0;i<off;i++)days.insertAdjacentHTML('beforeend','<span class="e"></span>');
  const n=new Date(y,m+1,0).getDate();
  for(let i=1;i<=n;i++){const d=new Date(y,m,i),b=document.createElement('button');b.type='button';b.textContent=i;
    if(d<today){b.disabled=true}else if(bookedSet.has(d.toDateString())){b.className='x';b.disabled=true;b.title='Booked'}else{b.className='o';b.onclick=()=>pickDate(d,true)}
    if(sel&&d.toDateString()===sel.toDateString())b.classList.add('s');days.appendChild(b)}};
function pickDate(d,fromCal){sel=d;$('#fDate').value=iso(d);$('#fDate').closest('.fld').classList.remove('err');renderCal();if(fromCal){toast(T('Date selected: ','Datum gewählt: ')+d.toLocaleDateString(lang==='de'?'de-DE':'en-GB',{weekday:'short',day:'numeric',month:'long',year:'numeric'}));if(innerWidth<1180)$('#form').scrollIntoView({behavior:'smooth',block:'start'})}}
$('#calPrev').onclick=()=>{view.setMonth(view.getMonth()-1);renderCal()};
$('#calNext').onclick=()=>{view.setMonth(view.getMonth()+1);renderCal()};
$('#fDate').min=iso(today);
$('#fDate').addEventListener('change',e=>{if(!e.target.value)return;const[y,m,d]=e.target.value.split('-').map(Number);const dt=new Date(y,m-1,d);
  if(bookedSet.has(dt.toDateString())){toast(T('That date is already booked. Please pick another.','Dieses Datum ist schon gebucht. Bitte ein anderes wählen.'));e.target.value='';return}
  sel=dt;view=new Date(y,m-1,1);renderCal()});
renderCal();

const form=$('#form');let step=1;
const showStep=n=>{step=n;$$('.pane').forEach(p=>p.classList.toggle('on',+p.dataset.step===n));$$('.prog i').forEach((p,i)=>p.classList.toggle('on',i<Math.min(n,3)))};
$$('.opts').forEach(w=>w.addEventListener('click',e=>{const b=e.target.closest('.opt,.xopt');if(!b)return;if(w.hasAttribute('data-single'))w.querySelectorAll('.opt').forEach(o=>o.classList.remove('on'));b.classList.toggle('on');if(w.id==='xgrid')$('#fldX').classList.remove('err')}));
const valid=n=>{let ok=true;
  form.querySelectorAll(`.pane[data-step="${n}"] [required]`).forEach(f=>{const bad=!f.value.trim()||(f.type==='email'&&!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(f.value));f.closest('.fld').classList.toggle('err',bad);if(bad)ok=false});
  if(n===2&&!$$('#xgrid .on').length){$('#fldX').classList.add('err');ok=false}
  if(!ok){const e=form.querySelector('.pane.on .err');e&&e.scrollIntoView({behavior:'smooth',block:'center'})}
  return ok};
form.querySelectorAll('input,select').forEach(f=>f.addEventListener('input',()=>f.closest('.fld').classList.remove('err')));
$$('[data-next]').forEach(b=>b.onclick=()=>{if(valid(step))showStep(step+1)});
$$('[data-back]').forEach(b=>b.onclick=()=>showStep(step-1));
let reqText='';
form.addEventListener('submit',e=>{e.preventDefault();if(!valid(3))return;
  const v=id=>$(id).value.trim(),list=s=>$$(s+' .on').map(o=>o.dataset.v?XN[o.dataset.v]:o.textContent).join(', ');
  const d=$('#fDate').value?new Date($('#fDate').value+'T00:00').toLocaleDateString('en-GB',{weekday:'short',day:'numeric',month:'long',year:'numeric'}):'';
  const rows=[['Date',d],['Location',v('#fCity')],['Event',v('#fType')],['Guests',v('#fGuests')],['Experience',list('#xgrid')],['Talk topic',list('#topics')],['Healing methods',list('#methods')],['Also interested in',list('#extras')],['Language',list('#langs')],['Name',v('#fName')],['Organisation',v('#fOrg')],['Email',v('#fEmail')],['Phone',v('#fPhone')],['Message',v('#fMsg')]].filter(r=>r[1]);
  $('#sum').innerHTML=rows.map(r=>`<div><span>${r[0]}</span><b>${r[1].replace(/</g,'&lt;')}</b></div>`).join('');
  reqText='Booking request for Miss Boldt\n\n'+rows.map(r=>r[0]+': '+r[1]).join('\n');
  $('#mailBtn').href='mailto:'+EMAIL+'?subject='+encodeURIComponent('Booking request · '+d+' · '+v('#fCity'))+'&body='+encodeURIComponent(reqText);
  const done=sent=>{const tp=$('.done [data-i18n="thxp"]')||$('#thxp');if(sent&&tp){tp.removeAttribute('data-i18n');tp.textContent=T('Your request has been sent to Miss Boldt. A confirmation is on its way to your email, and she will reply to you personally with a tailored plan and quote.','Deine Anfrage wurde an Miss Boldt gesendet. Eine Bestätigung ist per E-Mail unterwegs, und sie antwortet dir persönlich mit Plan und Angebot.');$('#mailBtn').style.display='none'}
    showStep(4);form.scrollIntoView({behavior:'smooth',block:'start'})};
  if(CFG&&CFG.ajax){const fd=new FormData();fd.append('action','mb_booking');fd.append('nonce',CFG.nonce);fd.append('summary',reqText);rows.forEach(r=>fd.append('f['+r[0]+']',r[1]));fd.append('date_iso',$('#fDate').value);fd.append('ui_lang',lang);
    const btn=form.querySelector('button[type=submit]');btn.disabled=true;btn.style.opacity=.6;
    fetch(CFG.ajax,{method:'POST',body:fd,credentials:'same-origin'}).then(r=>r.json()).then(j=>done(!!(j&&j.success))).catch(()=>done(false)).finally(()=>{btn.disabled=false;btn.style.opacity=''})}
  else done(false)});
$('#copyReq').onclick=()=>copy(reqText,T('Request copied','Anfrage kopiert'));
$('#newReq').onclick=()=>{form.reset();$$('#form .opt.on, #form .xopt.on').forEach(o=>o.classList.remove('on'));$('#langs .opt').classList.add('on');sel=null;renderCal();showStep(1)};

// picks sent from other pages
let p=[];try{p=JSON.parse(store.get('mb_picks')||'[]')}catch(e){}
if(p.length){p.forEach(([k,v])=>applyPick(k,v));store.del('mb_picks');const lbl=store.get('mb_toast');store.del('mb_toast');
  setTimeout(()=>{toast(T('Added to your request: ','Hinzugefügt: ')+lbl);document.getElementById('book').scrollIntoView({behavior:'smooth'})},1000)}
}

/* ---------- EN / DE ---------- */
const DE={
strip:'Konzept-Vorschau von <b>Olonade Abiodun</b> · noch nicht online',
n1:'Erlebnis',n2:'Vorträge',n3:'Über mich',n4:'Video',n5:'FAQ',n6:'Buchung',bookNow:'Jetzt buchen',
travel:'Reisebereit',
h1:'Singen,<br>Tanzen <span class="it">&amp; heilen.</span>',

checkDates:'Termine prüfen',watchLive:'Live ansehen',ww:'Deutschland &amp; weltweit',travelInc:'Reise im Angebot inklusive',np:'MUSIK · BALD VERFÜGBAR',
k1:'Das Erlebnis',h2exp:'Drei Wege, dein<br>Publikum zu <span class="it sand">bewegen</span>',pexp:'Eins buchen oder alle drei kombinieren. Karte antippen, um sie anzufragen.',
educate:'Bilden',sing:'Singen',dance:'Tanzen',c1:'Wellness-Vortrag',c2:'Live-Gesang',c3:'Erzählender Tanz',c3s:'Alle machen mit · Jedes Alter',c4:'Das volle Erlebnis',c4s:'Am häufigsten gebucht · 60–90 Min',
fbh:'Das volle <span class="it">ENTER~wellness</span> Erlebnis',fbp:'Vortrag, Gesang und Tanz in einer Session. Unser beliebtestes Format.',request:'Anfragen',
k2:'Vorträge &amp; Keynotes',h2talk:'Vorträge, die <span class="it orchid">heilen</span>',ptalk:'Sechs Themen, passend zu deinem Event. Antippen zum Anfragen.',
t1:'Heilung von sexuellen &amp; emotionalen Traumata',t1p:'Ihre Folgen und der Weg hinaus.',t2:'Ein gesunder Lebensstil',t2p:'Körper, Geist und Seele im Gleichgewicht.',t3:'Deine Bestimmung finden',t3p:'Sie entdecken und täglich leben.',t4:'Vergebung &amp; Toleranz',t4p:'Freiheit für dich und dein Umfeld.',t5:'Fehler annehmen',t5p:'Verantwortung, die befreit.',t6:'Ein Traumleben aufbauen',t6p:'Von der Vision zu täglichen Schritten.',ask:'DIESEN VORTRAG ANFRAGEN →',
lgh:'Eine Stimme,<br><span class="it sand">drei Sprachen</span>',lgp:'In alles eingebunden, was sie tut: für kulturelle Vielfalt und echte Verbindung.',mt:'Twi · Fanti',
k3:'In ihren Worten',quote:'Wenn ich <span>singe</span> und <span>tanze</span>, sende ich heilende Schwingungen an alle um mich herum.',
k4:'Die Künstlerin',h2about:'Eine spirituelle <span class="it">Kriegerin</span>',pabout:'Sie stellt sich Gewalt und Ungleichheit mit <b>Musik und Bewegung</b> entgegen. Sechs Jahre, in denen sie Schmerz in Weisheit verwandelt hat, und Weisheit in Heilung für andere.',s1:'Jahre Heilungsarbeit',s2:'Vortrag, Gesang &amp; Tanz',s3:'Sprachen: EN · DE · Akan',
k5:'Mehr als die Bühne',h2roles:'Mehr als<br>eine <span class="it gold">Performerin</span>',proles:'Eine Künstlerin, viele Gaben. Antippen zum Anfragen.',
r1:'Persönlicher Life Coach',r1p:'Begleitung im Einzelgespräch, um zu heilen und zu wachsen.',r2:'Rednerin',r2p:'Keynotes und Vorträge, die bewegen.',r3:'Singer-Songwriterin',r3p:'Eigene Songs mit heilender Botschaft.',r4:'Erzählende Tänzerin',r4p:'Geschichten, erzählt durch Körper und Bewegung.',r5:'Autorin',r5p:'Worte über Heilung, Bestimmung und Leben.',r6:'Schauspielerin',r6p:'Rollen auf Bühne und Leinwand.',r7:'Model',r7p:'Foto-, Mode- und Markenarbeit.',r8:'Event-Planungsassistenz',r8p:'Hilfe, dein Event lebendig zu machen. <b style="color:var(--gold)">+ mehr</b>',
unplug:'Live, unplugged, unvergesslich.',k6:'✦ Perfekt für',h2stage:'Jede Bühne.<br><span class="it">Jedes Publikum.</span>',
plist:'<span>Wellness-Retreats</span> <em>✦</em> <span>Festivals</span> <em>✦</em> <span>Toleranz- &amp; Vielfaltstage</span> <em>✦</em> <span>Schulen &amp; Jugendarbeit</span> <em>✦</em> <span>Betriebliche Gesundheit</span> <em>✦</em> <span>Private Feiern</span> <em>✦</em> <span>Gemeinde-Events</span>',
recentLive:'Zuletzt auf der Bühne beim <b>Internationalen Tag der Toleranz</b> mit toll.ev',
k7:'Auf der Bühne',h2recent:'Letzte <span class="it sand">Auftritte</span>',performed:'AUFGETRETEN',cafe:'Live im Café',yourDate:'Dein Termin<small>2026 · 2027</small>',yourEv:'Dein Retreat, Festival <i>oder Fest</i>',ww2:'Deutschland &amp; weltweit · Reise inklusive',
k8:'Video',h2watch:'Spür die <span class="it sand">Energie</span>',pwatch:'Sieh sie live, bevor du buchst.',v1:'Live im Café',v2:'Tag der Toleranz',
h2book:'Buche <span class="it orchid">Miss Boldt</span>',pbook:'Kostenlos und unverbindlich. Persönliche Antwort mit Plan und Angebot.',
st1:'Datum wählen',st1p:'Freie Termine direkt im Kalender.',st2:'Event beschreiben',st2p:'Wo, wer und was. Zwei Minuten.',st3:'Angebot erhalten',st3p:'Individueller Plan und Preis, Reise inklusive.',
open:'Frei',booked:'Gebucht',yours:'Dein Datum',calTravel:'<b>Reisebereit.</b> Deutschland und weltweit. Reisekosten sind im Angebot enthalten.',
s1of3:'Schritt 1 von 3 · Dein Event',fh1:'Dein Event',lDate:'Datum',lCity:'Stadt &amp; Land',lType:'Art des Events',lGuests:'Erwartete Gäste',eDate:'Bitte ein Datum wählen.',eReq:'Bitte ausfüllen.',ePick:'Bitte auswählen.',free:'Kostenlos · Unverbindlich · Persönliche Antwort',cont:'Weiter',
s2of3:'Schritt 2 von 3 · Das Erlebnis',fh2:'Was wünschst du dir?',lExp:'Eins oder mehrere wählen',eExp:'Bitte mindestens eins wählen.',lTopic:'Vortragsthema (optional)',lAlso:'Auch interessiert an (optional)',lLang:'Sprache',back:'Zurück',
s3of3:'Schritt 3 von 3 · Deine Daten',fh3:'Wem soll sie antworten?',lName:'Dein Name',lOrg:'Organisation (optional)',lEmail:'E-Mail',lPhone:'Telefon / WhatsApp (optional)',lMsg:'Noch etwas? (optional)',eEmail:'Bitte eine gültige E-Mail eingeben.',send:'Anfrage senden',
thx:'Danke!',thxp:'Hier ist deine Anfrage. Sende sie per E-Mail an Miss Boldt, und sie antwortet dir persönlich mit Plan und Angebot.',emailIt:'Per E-Mail senden',copyReq:'Anfrage kopieren',mailNote:'Dein Mailprogramm öffnet sich, adressiert an',newReq:'Neue Anfrage starten',
h2faq:'Gut zu <span class="it">wissen</span>',pfaq:'Noch eine Frage? Schreib sie in deine Anfrage.',
q1:'Reist du für Events?',a1:'Ja. In ganz Deutschland und weltweit. Reisekosten sind in jedem Angebot enthalten.',q2:'In welchen Sprachen trittst du auf?',a2:'Englisch, Deutsch und Akan (Twi/Fanti), ihre Muttersprache aus Ghana. Vorträge können Sprachen für ein vielfältiges Publikum mischen.',q3:'Wie lange dauert ein Auftritt?',a3:'Ein Vortrag dauert 20–45 Minuten. Das volle 3-in-1-Erlebnis 60–90 Minuten. Alles ist anpassbar.',q4:'Passt der Vortrag zu unserem Thema?',a4:'Ja. Wähle eines ihrer sechs Themen oder nenne dein Thema, und sie passt den Vortrag an.',q5:'Ist eine Anfrage verbindlich?',a5:'Nein. Sie ist kostenlos und unverbindlich. Du bekommst zuerst ein persönliches Angebot.',
h2cta:'Lass uns etwas<br><span class="it">Heilendes</span> schaffen',copy:'KOPIEREN',bio:'Sängerin, Tänzerin, Rednerin und Life Coach. Bringt ENTER~wellness zu Events in Deutschland und weltweit.',explore:'ENTDECKEN',bookings:'BUCHUNG',follow:'FOLGEN',
vmsg:'Hier läuft Miss Boldts Auftrittsvideo, sobald es hochgeladen ist.',vlike:'Gefällt dir, was du siehst?',bring:'Zu deinem Event holen',legal:'Impressum und Datenschutzerklärung werden vor dem Livegang ergänzt.',
roles3:'Wellness-Rednerin · Sängerin · Tänzerin',lead:'Wellness-Vorträge, Live-Gesang und Tanz für dein Event, dazu 1:1-Lifecoaching. Gemeinsam besser fühlen, in Körper, Geist und Seele.',ofK:'Was du buchen kannst',ofH:'Zwei Wege, <span class="it sand">mit ihr zu arbeiten</span>',ofP:'Miss Boldt (Niomi Boldt) ist Wellness-Rednerin, Sängerin, Tänzerin und Lifecoach. Das bietet sie an, und für wen.',of1T:'Für Events &amp; Veranstalter',of1H:'Das ENTER~wellness-Erlebnis',of1P:'Ein kurzer Wellness-Vortrag, Live-Gesang und ein Tanz, bei dem alle mitmachen, von 20 bis 90 Minuten. Deine Gäste gehen leichter, verbundener und mit einfachen Ideen für ein gesünderes Leben nach Hause.',of1a:'Für Retreats, Festivals, Schulen, Unternehmen, Gemeindeevents und Feiern',of1b:'Auf Englisch, Deutsch oder Akan · Deutschland &amp; weltweit · Anreise inklusive',of2T:'Für Einzelpersonen',of2H:'1:1 Wellness- &amp; Lifecoaching',of2P:'Persönliches Coaching für einen gesünderen, glücklicheren Lebensstil: einfache Essensplanung, leichte Bewegung und eine positive Haltung, Schritt für Schritt.',of2a:'Für alle, die sich in Körper, Geist und Seele besser fühlen möchten',of2b:'Auf Englisch, Deutsch oder Akan · über 500 gecoachte Menschen in Ghana und weltweit',ofMeanH:'Was „Heilung“ hier bedeutet',ofMeanP:'Sich besser fühlen in Körper, Geist und Seele, durch Musik, Bewegung, Natur und einen gesünderen Lebensstil. Ihre Angebote fördern das Wohlbefinden; sie ersetzen keine ärztliche oder psychotherapeutische Behandlung.',ofWhyH:'Warum Miss Boldt buchen',ofWhyP:'6+ Jahre Wellness-Arbeit · 500+ gecoachte Menschen · Englisch, Deutsch &amp; Akan · Internationaler Tag der Toleranz mit toll.ev'
};
const TW={
npOn:'SEESEI YI',
nineK:'Ne ayaresa nkyerɛkyerɛ',nineH2:'Abɔdeɛ akwan <span class="it">a ɛsa yare</span>',hmAdd:'Fa ka m\'abisadeɛ ho +',gPerform:'Agua so',gBody:'Nipadua &amp; asetena',gSpirit:'Honhom &amp; anigyeɛ',lMethods:'Ayaresa akwan (ɛho nhia)',
hm1:'Saw na sa yare',hm2:'To dwom na sa yare',hm3:'Yɛ sɛ abofra na sa yare',hm4:'Kasa na sa yare',hm5:'Di aduane pa na sa yare',hm6:'Apɔmuden &amp; nipadua mmerɛyɛ',hm7:'Hwɛ wo ho &amp; dɔ wo ho',hm8:'Gye di na sa yare',hm9:'Di afahyɛ na sa yare',
before:'KANSA',after:'SEESEI',tfB:'Ɛhɔ na ɛfiri ase',tfA:'Seesei asetena',realRes:'NSƐNOAHUNU ANKASA',drag:'← TWE NA HWƐ →',coachK:'Apɔmuden akwankyerɛ',coachH:'Odwumayɛfo <span class="it">a ɔkyerɛ kwan</span>',coachH2:'Odwumayɛfo <span class="it orchid">a ɔkyerɛ kwan</span>',p1:'Aduane nhyehyɛe',p2:'Apɔw-mu-teɛteɛ',p3:'Adwene pa',b1:'nnipa a ɔaboa wɔn',b2:'Ghana &amp; aburokyiri',startJ:'Fi wo akwantuo ase',
strip:'Nhyehyɛe a <b>Olonade Abiodun</b> ayɛ · ennya mmaa intanɛt so',
nHome:'Fie',nLive:'Agoru &amp; Nnwom',nAbout:'Me ho asɛm &amp; Kasa',nBook:'Hyɛ da',n2:'Kasa',n5:'Nsɛmmisa',n6:'Hyɛ da',crHome:'Fie',
bookNow:'Hyɛ da seesei',travel:'Wasiesie ne ho sɛ ɔbɛtu kwan',
h1:'To dwom,<br>Saw <span class="it">&amp; sa yare.</span>',

checkDates:'Hwɛ nna',watchLive:'Hwɛ ne agoru',ww:'Germany &amp; wiase nyinaa',travelInc:'Akwantuo ka ho',np:'NNWOM · ƐREBA',
k1:'Dwumadi no',h2exp:'Akwan mmiɛnsa a ɛbɛ<br><span class="it sand">kanyan</span> wo nnipa',pexp:'Paw baako, anaa fa ne nyinaa bom. Mia kaad bi so na bisa.',
educate:'Kyerɛkyerɛ',sing:'To dwom',dance:'Saw',c1:'Apɔmuden kasa',c2:'Nnwom a ɛte ase',c3:'Asaw a ɛka asɛm',c4:'Dwumadi no nyinaa',
fbh:'<span class="it">ENTER~wellness</span> dwumadi no nyinaa',fbp:'Kasa, nnwom ne asaw wɔ bere baako mu.',request:'Bisa',
k2:'Kasa',h2talk:'Kasa a ɛsa <span class="it orchid">yare</span>',ptalk:'Nsɛm asia, wɔbɛhyehyɛ ama wo dwumadi. Mia baako so na bisa.',ask:'BISA SAA KASA YI →',
t1:'Ayaresa firi ɔbra ne akoma mu yaw mu',t2:'Asetena pa a apɔmuden wom',t3:'Wo botaeɛ wɔ asetena mu',t4:'Bɔne fakyɛ &amp; ntoboaseɛ',t5:'Gye wo mfomsoɔ tom',t6:'Si w\'asetena pa',
lgh:'Nne baako,<br><span class="it sand">kasa mmiɛnsa</span>',lgp:'Ɔde ka nneɛma a ɔyɛ nyinaa ho, ma amammerɛ ahorow ne nkitahodi pa.',mt:'Twi · Fanti',
k3:'Ne nsɛm',quote:'Sɛ mito <span>dwom</span> na misaw <span>asaw</span> a, mede ayaresa mu ahoɔden ma obiara a ɔwɔ me ho.',
k4:'Odwumayɛfo no',h2about:'Honhom mu <span class="it">ɔkofo</span>',s1:'mfeɛ a ɔde asa yare',s2:'kasa, nnwom &amp; asaw',s3:'kasa: EN · DE · Akan',
k5:'Ɛboro agua no so',h2roles:'Ɔboro<br><span class="it gold">agorumfo</span>',proles:'Odwumayɛfo baako, akyɛdeɛ pii. Mia biara so na bisa.',
r1:'Asetena ho ɔkyerɛkyerɛfo',r2:'Kasafo',r3:'Odwontofo &amp; nnwom kyerɛwfo',r4:'Ɔsawfo a ɔka asɛm',r5:'Nwomakyerɛwfo',r6:'Agorufo',r7:'Model',r8:'Dwumadi nhyehyɛe boafo',
k6:'✦ Ɛfata ma',h2stage:'Agua biara.<br><span class="it">Nnipa biara.</span>',
k7:'Agua so',h2recent:'Agoru a <span class="it sand">atwam</span>',performed:'WAYƐ',
k8:'Hwɛ',h2watch:'Te <span class="it sand">ahoɔden</span> no',pwatch:'Hwɛ ne agoru ansa na woahyɛ da.',
h2book:'Hyɛ da ma <span class="it orchid">Miss Boldt</span>',pbook:'Ɛyɛ kwa na ɛmfa wo nhyɛ. Ɔbɛyi ano ankasa.',
st1:'Paw da',st1p:'Nna a ɛda hɔ wɔ kalenda no so.',st2:'Ka wo dwumadi ho asɛm',st2p:'Ɛhe, hwan ne dɛn. Simma mmienu.',st3:'Nya wo nhyehyɛe',st3p:'Nhyehyɛe ne ka, akwantuo ka ho.',
open:'Ɛda hɔ',booked:'Wɔahyɛ',yours:'Wo da',calTravel:'<b>Wasiesie ne ho sɛ ɔbɛtu kwan.</b> Germany ne wiase nyinaa. Akwantuo ka ho.',
s1of3:'Anammɔn 1 wɔ 3 mu · Wo dwumadi',fh1:'Wo dwumadi',lDate:'Da',lCity:'Kuro &amp; ɔman',lType:'Dwumadi no su',lGuests:'Ahɔhoɔ dodoɔ',eDate:'Yɛsrɛ wo, paw da.',eReq:'Yɛsrɛ wo, hyɛ ma.',ePick:'Yɛsrɛ wo, paw baako.',free:'Ɛyɛ kwa · Ɛmfa wo nhyɛ · Ɔbɛyi ano ankasa',cont:'Toa so',
s2of3:'Anammɔn 2 wɔ 3 mu · Dwumadi no',fh2:'Dɛn na wopɛ?',lExp:'Paw baako anaa pii',eExp:'Yɛsrɛ wo, paw baako pɛ.',lTopic:'Kasa asɛmti (ɛho nhia)',lAlso:'Wopɛ eyi nso (ɛho nhia)',lLang:'Kasa',back:'San w\'akyi',
s3of3:'Anammɔn 3 wɔ 3 mu · Wo ho nsɛm',fh3:'Hwan na ɔnyi ano mma?',lName:'Wo din',lOrg:'Ekuo (ɛho nhia)',lEmail:'Email',lPhone:'Fon / WhatsApp (ɛho nhia)',lMsg:'Biribi foforɔ? (ɛho nhia)',eEmail:'Yɛsrɛ wo, hyɛ email pa.',send:'Fa abisadeɛ no mena',
thx:'Meda wo ase!',emailIt:'Fa email mena',copyReq:'Yɛ abisadeɛ no nsɛsoɔ',newReq:'Fi abisadeɛ foforɔ ase',
h2faq:'Nsɛm a ɛsɛ sɛ <span class="it">wohunu</span>',
h2cta:'Ma yɛnyɛ biribi<br>a ɛsa <span class="it">yare</span>',copy:'YƐ NSƐSOƆ',explore:'HWEHWƐ',bookings:'HYƐ DA',follow:'DI W\'AKYI',
liveH1:'Agoru <span class="it">&amp; nnwom</span>',fAll:'Ne nyinaa',fMusic:'Nnwom',fDance:'Asaw',fTalks:'Kasa',upB:'Fa video ka ho',
musicK:'Nnwom',musicH:'Tie ne <span class="it sand">nne</span>',galK:'Mfoni',galH:'Bere a <span class="it orchid">wɔakyere</span>',showsK:'Nna',showsH:'Agoru <span class="it sand">&amp; nna</span>',tUp:'NEA ƐREBA',tPast:'NEA ATWAM',
aboutH1:'Ne ho asɛm <span class="it">&amp; kasa</span>',testK:'Nsɛm pa',testH:'Deɛ ahɔhoɔ <span class="it orchid">ka</span>',sample:'NHWƐSO',
bookH1:'Hyɛ da ma <span class="it">Miss Boldt</span>',i1:'Akwantuo ka ho',i1p:'Germany &amp; wiase nyinaa',i2:'Ɛyɛ kwa',i2p:'Nya nhyehyɛe, na afei paw',i3:'Ɔbɛyi ano ankasa',i3p:'Firi Miss Boldt ankasa hɔ',
nextK:'KRATAAFA A ƐDI HƆ',next1:'Agoru <span class="it">&amp; nnwom</span>',next2:'Ne ho asɛm <span class="it">&amp; kasa</span>',next3:'Hyɛ da <span class="it">seesei</span>',next4:'San kɔ <span class="it">fie</span>',
aboutTeaserK:'Hyia Miss Boldt',aboutTeaserH:'To dwom, saw <span class="it">&amp; sa yare</span>',readStory:'Kenkan ne ho asɛm',seeShows:'Hwɛ agoru no nyinaa',
roles3:'Wellness kasafo · Odwontofo · Ɔsawfo',lead:'Wellness nkɔmmɔbɔ, nnwom ne asaw ma wo dwumadi, ne 1:1 abrabɔ akwankyerɛ. Yɛn nyinaa nte apɔ wɔ nipadua, adwene ne honhom mu.',ofK:'Deɛ wobɛtumi ahyɛ',ofH:'Akwan mmienu <span class="it sand">a wo ne no bɛyɛ adwuma</span>',of1T:'Ma dwumadi ne ahyehyɛfoɔ',of2T:'Ma ankorankoro',of2H:'1:1 wellness &amp; abrabɔ akwankyerɛ',ofMeanH:'Deɛ “ayaresa” kyerɛ wɔ ha',ofWhyH:'Adɛn nti na ɛsɛ sɛ wohyɛ Miss Boldt'
};

Object.assign(DE,{
nineK:'Ihre Heilungsphilosophie',nineH2:'Natürliche Wege <span class="it">zu heilen</span>',nineP2:'Heilung mit Musik und Bewegung, verwurzelt in Natur, Glauben, Lebensstil und Feiern.',
philo:'Natürliche Wege der Heilung mit Musik und Bewegung, verwurzelt in Natur, Glauben, Lebensstil und Feiern.',p4:'9 natürliche Heilmethoden →',
gPerform:'Auf der Bühne',gBody:'Körper &amp; Lebensstil',gSpirit:'Geist &amp; Freude',hmAdd:'Zur Anfrage hinzufügen +',nineCta:'Wähle die Wege, die dich ansprechen, für dein Event oder deine eigene Reise.',lMethods:'Heilmethoden (optional)',
hm1:'Tanzen, um zu heilen',hm1p:'Bewege deine Geschichte aus dem Körper und lass Gefühle fließen.',hm2:'Singen, um zu heilen',hm2p:'Deine Stimme trägt heilende Schwingungen, für dich und andere.',
hm3:'Kind sein, um zu heilen',hm3p:'Spielen, lachen und dein inneres Kind wiederfinden.',hm4:'Sprechen, um zu heilen',hm4p:'Ehrliche Worte und geteilte Geschichten, die das Herz befreien.',
hm5:'Essen, um zu heilen',hm5p:'Nährendes Essen und einfache Pläne, die dein Leben stärken.',hm6:'Fitness &amp; Beweglichkeit',hm6p:'Leichte Bewegung und Dehnung für einen starken, freien Körper.',
hm7:'Selbstfürsorge &amp; Liebe',hm7p:'Ruhe, Freundlichkeit und das Wissen um deinen eigenen Wert.',hm8:'Glauben, um zu heilen',hm8p:'Glaube und innere Stärke: der Anker, der dich hält.',
hm9:'Feiern, um zu heilen',hm9p:'Dankbarkeit und Freude: feiere jeden Schritt deines Lebens.',
npOn:'IM FOKUS',musicSoon:'Ihre Aufnahmen folgen bald. Die Titel sind Platzhalter.',before:'VORHER',after:'NACHHER',tfB:'Wo es begann',tfA:'Heute gelebt',tfT:'VERWANDLUNG',realRes:'ECHTES ERGEBNIS',liveWhat:'„Ich lebe, was ich lehre.“',drag:'← ZIEHEN ZUM VERGLEICHEN →',coachK:'Wellness-Coaching',coachH:'Künstlerin, <span class="it">die coacht</span>',coachH2:'Künstlerin, <span class="it orchid">die coacht</span>',
coachP:'Über <b>500 Menschen</b> in Ghana und im Ausland hat sie auf ihrem Wellness-Weg begleitet, und sie ist ihn selbst gegangen.',coachP2:'Über 500 Menschen in Ghana und im Ausland auf ihrem Wellness-Weg begleitet.',
p1:'Ernährungsplanung',p2:'Einfache Übungen',p3:'Lifestyle-Mindset',p4:'9 natürliche Heilmethoden',b1:'Menschen gecoacht',b2:'Ghana &amp; Ausland',b3:'natürliche Heilmethoden',startJ:'Starte deine Reise',coachMore:'So coacht sie',
cc1:'Einfache, nährende Pläne, die zum echten Leben und Budget passen.',cc2:'Leichte Bewegungsroutinen, mit denen jeder heute starten kann.',cc3:'Ein starkes, beständiges Mindset, damit Veränderung bleibt.',
nineH:'Natürliche <i>Heilmethoden</i>',nineP:'Ihr Coaching verbindet sich jetzt mit 9 natürlichen Heilmethoden für Körper, Geist und Seele.',proofK:'Ihr eigener Weg',proofH:'Der Beweis, dass es <i>wirkt</i>',
proofP:'Als Coach war dies ihre persönliche Abnehm-Transformation. Ernährungsplanung, einfache Übungen und ein beständiges Mindset: derselbe Weg, den sie heute mit anderen teilt.',
nHome:'Start',nLive:'Live &amp; Musik',nAbout:'Über &amp; Vorträge',nBook:'Buchen',
crHome:'Start',
aboutTeaserK:'Lerne sie kennen',aboutTeaserH:'Singen, Tanzen <span class="it">&amp; heilen</span>',aboutTeaserP:'Sängerin, Tänzerin, Rednerin und Life Coach. Sie verwandelt Schmerz in Weisheit und Weisheit in Heilung, in drei Sprachen.',
readStory:'Ihre Geschichte lesen',seeShows:'Alle Shows ansehen',
liveH1:'Live <span class="it">&amp; Musik</span>',liveLead:'Shows, Live-Musik und Tanz. Sieh, hör und spür sie, bevor du buchst.',
fAll:'Alle',fMusic:'Live-Musik',fDance:'Tanz',fTalks:'Vorträge',
upH:'Neue Shows kommen hierher',upP:'Schick uns Videos oder YouTube-, Instagram- oder Facebook-Links, und sie erscheinen auf dieser Seite.',upB:'Video hinzufügen',
musicK:'Musik',musicH:'Hör ihre <span class="it sand">Stimme</span>',musicP:'Soulful, unplugged und voller heilender Schwingungen.',
galK:'Galerie',galH:'Momente <span class="it orchid">festgehalten</span>',galP:'Tippe auf ein Foto, um es groß zu sehen.',
showsK:'Termine',showsH:'Shows <span class="it sand">&amp; Termine</span>',tUp:'KOMMEND',tPast:'VERGANGEN',
aboutH1:'Über <span class="it">&amp; Vorträge</span>',aboutLead:'Die Künstlerin, ihre Geschichte und die Botschaften, die sie auf die Bühne bringt.',
storyP2:'Ihr Ansatz, ENTER~wellness, verbindet Unterhaltung und Wellness: Musik, Bewegung und ein gesunder, aktiver Lebensstil, gemeinsam mit der Natur, um Heilung in Körper, Geist und Seele zu wecken.',
testK:'Stimmen',testH:'Was Gäste <span class="it orchid">sagen</span>',testP:'Beispiele, bis echte Bewertungen da sind.',sample:'BEISPIEL',
bookH1:'Buche <span class="it">Miss Boldt</span>',bookLead:'Wähle ein Datum, beschreibe dein Event und erhalte ein persönliches Angebot. Kostenlos und unverbindlich.',
i1:'Reise inklusive',i1p:'Deutschland &amp; weltweit',i2:'Kostenlos &amp; unverbindlich',i2p:'Erst Angebot, dann entscheiden',i3:'Persönliche Antwort',i3p:'Direkt von Miss Boldt',
nextK:'NÄCHSTE SEITE',next1:'Live <span class="it">&amp; Musik</span>',next2:'Über <span class="it">&amp; Vorträge</span>',next3:'Jetzt <span class="it">buchen</span>',next4:'Zurück zum <span class="it">Start</span>'
});
const EN={};$$('[data-i18n]').forEach(el=>{EN[el.dataset.i18n]??=el.innerHTML});
function setLang(l){lang=l;document.documentElement.lang=l;store.set('mb_lang',l);
  const D=l==='de'?DE:l==='tw'?TW:EN;$$('[data-i18n]').forEach(el=>{const k=el.dataset.i18n,t=D[k]??EN[k];if(t!=null)el.innerHTML=t});
  $$('[data-lang]').forEach(b=>b.classList.toggle('on',b.dataset.lang===l));renderCal()}
$$('[data-lang]').forEach(b=>b.onclick=()=>setLang(b.dataset.lang));
{const sl=store.get('mb_lang');if(sl==='de'||sl==='tw')setLang(sl)}
})();
