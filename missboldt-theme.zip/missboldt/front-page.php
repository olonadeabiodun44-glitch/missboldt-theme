<?php
/* front-page */
get_header(); ?>
<!-- HERO -->
<section class="hero" id="top">
  <div class="wrap grid">
    <div class="reveal">
      <div class="chips">
        <span class="chip g" data-i18n="travel">Ready to travel</span>
        <span class="chip" data-i18n="roles3">Wellness speaker · Singer · Dancer</span>
      </div>
      <h1 class="disp" data-i18n="h1">Sing,<br>Dance <span class="it">&amp; heal.</span></h1>
      <p class="lead" data-i18n="lead">Wellness talks, live singing and dance for your event, plus 1:1 life coaching. Feel better together, in body, mind and spirit.</p>
      <div class="ctas">
        <a class="btn solid" href="<?php echo mb_url('book',''); ?>"><span data-i18n="checkDates">Check dates</span> <span>→</span></a>
        <button class="btn ghost" data-video="0">▶&nbsp; <span data-i18n="watchLive">Watch her live</span></button>
      </div>
      <div class="chips" style="margin-top:34px">
        <span class="chip"><span class="flag"></span> English · Deutsch · Akan</span>
        <span class="chip" data-i18n="ww">Germany &amp; worldwide</span>
      </div>
    </div>
    <div class="vbox"><div class="visual" id="visual">
      <div class="sun"></div>
      <div class="archline"></div>
      <div class="arch" id="slides">
        <img class="on" src="<?php echo esc_url( MB_URI ); ?>/img/portrait.jpg" alt="Niomi Boldt smiling in a purple hat" data-cap="Meet Miss Boldt">
        <img src="<?php echo esc_url( MB_URI ); ?>/img/stage.jpg" alt="Niomi Boldt singing live at a café" data-cap="Live at the café">
        <img src="<?php echo esc_url( MB_URI ); ?>/img/tolerance.jpg" alt="Niomi Boldt dancing at the Day for Tolerance" style="object-position:72% 40%" data-cap="Day for Tolerance">
        <div class="slab" id="slab">Meet Miss Boldt</div>
      </div>
      <svg class="ring" viewBox="0 0 130 130" aria-hidden="true"><defs><path id="c" d="M65,65 m-52,0 a52,52 0 1,1 104,0 a52,52 0 1,1 -104,0"/></defs><text font-size="10.5" letter-spacing="3.2" fill="#ead0a8" font-family="Manrope" font-weight="700"><textPath href="#c">EDUCATE ✦ ENTERTAIN ✦ HEAL ✦ INSPIRE ✦</textPath></text><circle cx="65" cy="65" r="34" fill="#1b0918" stroke="#f2b84b"/><path d="M52 76c0-16 10-25 26-27-1 16-10 26-26 27zm0 0 18-18" stroke="#f2b84b" stroke-width="2" fill="none"/></svg>
      <div class="polaroid"><img src="<?php echo esc_url( MB_URI ); ?>/img/nature.jpg" alt="Niomi in nature"><span>in nature</span></div>
      <div class="badge"><i>✈</i><div><b data-i18n="ww">Germany &amp; worldwide</b><small data-i18n="travelInc">Travel included in every quote</small></div></div>
      <svg class="leaf" width="110" height="250" viewBox="0 0 110 250" aria-hidden="true"><path d="M20 248 C50 170 70 90 92 4" stroke="#86b85c" stroke-width="3" fill="none"/><g fill="#86b85c"><ellipse cx="80" cy="40" rx="22" ry="9" transform="rotate(-30 80 40)"/><ellipse cx="55" cy="58" rx="22" ry="9" transform="rotate(30 55 58)"/><ellipse cx="76" cy="95" rx="24" ry="10" transform="rotate(-25 76 95)"/><ellipse cx="45" cy="118" rx="24" ry="10" transform="rotate(35 45 118)"/><ellipse cx="62" cy="155" rx="24" ry="10" transform="rotate(-25 62 155)"/></g></svg>
    </div></div>
  </div>
  <div class="heroBar"><?php $mb_song = mb_first_song(); ?><div class="wrap" id="player"<?php if ( $mb_song ) echo ' data-src="' . esc_url( $mb_song['src'] ) . '"'; ?>>
    <div class="player"><button class="play" id="playBtn" aria-label="Play"><svg class="py" width="18" height="20"><path d="M2 1l15 9-15 9z" fill="#1b0918"/></svg><svg class="pz" width="16" height="18"><path d="M2 1h4v16H2zM10 1h4v16h-4z" fill="#1b0918"/></svg></button><div class="np"><?php if ( $mb_song ) { ?><small data-i18n="npOn">NOW FEATURING</small><b><?php echo esc_html( $mb_song['title'] ); ?> · Miss Boldt</b><?php } else { ?><small data-i18n="np">MUSIC · COMING SOON</small><b>Live at the café · Miss Boldt</b><?php } ?></div></div>
    <div class="wave" id="wave" title="Seek"></div>
    <div class="time" id="time">0:00 / 2:15</div>
    <div class="sctl"><div class="counter" id="counter">01 <span>/ 03</span></div><button class="arrow" id="prev" aria-label="Previous slide">←</button><button class="arrow" id="next" aria-label="Next slide">→</button></div>
  </div></div>
</section>

<!-- MARQUEE -->
<div class="marquee" aria-hidden="true">
  <div class="mtrack"><span class="disp">Life coach</span><em>✦</em><span class="it sand">speaker</span><em>✦</em><span class="disp o">Singer-songwriter</span><em>✦</em><span class="disp">Storytelling dancer</span><em>✦</em><span class="it sand">author</span><em>✦</em><span class="disp o">Actress</span><em>✦</em><span class="disp">Model</span><em>✦</em><span class="it sand">event planner</span><em>✦</em></div>
  <div class="mtrack"><span class="disp">Life coach</span><em>✦</em><span class="it sand">speaker</span><em>✦</em><span class="disp o">Singer-songwriter</span><em>✦</em><span class="disp">Storytelling dancer</span><em>✦</em><span class="it sand">author</span><em>✦</em><span class="disp o">Actress</span><em>✦</em><span class="disp">Model</span><em>✦</em><span class="it sand">event planner</span><em>✦</em></div>
</div>

<section class="offer" id="offer"><div class="wrap">
  <div class="head reveal">
    <div><div class="kicker" data-i18n="ofK">What you can book</div><h2 class="disp" data-i18n="ofH">Two ways to <span class="it sand">work with her</span></h2></div>
    <p data-i18n="ofP">Miss Boldt (Niomi Boldt) is a wellness speaker, singer, dancer and life coach. This is what she offers, and who it is for.</p>
  </div>
  <div class="ofgrid">
    <div class="ofc reveal">
      <div class="oft" data-i18n="of1T">For events &amp; organisers</div>
      <h3 data-i18n="of1H">The ENTER~wellness experience</h3>
      <p data-i18n="of1P">A short wellness talk, live singing and a dance that everyone joins, from 20 to 90 minutes. Your guests leave lighter, more connected and with simple ideas for a healthier life.</p>
      <ul>
        <li data-i18n="of1a">For retreats, festivals, schools, companies, community events and celebrations</li>
        <li data-i18n="of1b">In English, German or Akan · Germany &amp; worldwide · travel included</li>
      </ul>
      <a class="btn solid" href="<?php echo mb_url('book',''); ?>"><span data-i18n="checkDates">Check dates</span> <span>→</span></a>
    </div>
    <div class="ofc alt reveal">
      <div class="oft" data-i18n="of2T">For individuals</div>
      <h3 data-i18n="of2H">1:1 wellness &amp; life coaching</h3>
      <p data-i18n="of2P">Personal coaching for a healthier, happier lifestyle: simple meal planning, easy movement and a positive mindset, step by step.</p>
      <ul>
        <li data-i18n="of2a">For anyone who wants to feel better in body, mind and spirit</li>
        <li data-i18n="of2b">In English, German or Akan · 500+ people coached in Ghana and abroad</li>
      </ul>
      <button class="btn ghost" data-role="Life coaching"><span data-i18n="startJ">Start your journey</span> <span>→</span></button>
    </div>
  </div>
  <div class="ofnote reveal">
    <div><b data-i18n="ofMeanH">What “healing” means here</b><p data-i18n="ofMeanP">Feeling better in body, mind and spirit, through music, movement, nature and a healthier lifestyle. Her sessions support well-being; they are not a replacement for medical or psychological treatment.</p></div>
    <div><b data-i18n="ofWhyH">Why book Miss Boldt</b><p data-i18n="ofWhyP">6+ years of wellness work · 500+ people coached · English, German &amp; Akan · International Day for Tolerance with toll.ev</p></div>
  </div>
</div></section>
<!-- EXPERIENCE -->
<section class="exp" id="experience"><div class="wrap">
  <div class="head reveal">
    <div><div class="kicker" data-i18n="k1">The experience</div><h2 class="disp" data-i18n="h2exp">Three ways to<br><span class="it sand">move</span> your crowd</h2></div>
    <p data-i18n="pexp">Book one, or combine all three into one journey. Tap a card to request it.</p>
  </div>
  <div class="swipehint">SWIPE <i></i></div><div class="cards">
    <button class="card reveal" data-pick="talk"><div class="img"><img src="<?php echo esc_url( MB_URI ); ?>/img/bw.jpg" style="object-position:50% 20%" alt="Black and white portrait of Niomi Boldt, wellness speaker and life coach"><span class="go">↗</span><h3 class="disp" data-i18n="educate">Educate</h3></div><div class="meta"><b data-i18n="c1">Wellness talk</b><i>01</i></div><small>Talk · Q&amp;A · 20–45 min</small></button>
    <button class="card reveal" data-pick="sing"><div class="img"><img src="<?php echo esc_url( MB_URI ); ?>/img/stage.jpg" alt="Miss Boldt singing live at an unplugged café session"><span class="go">↗</span><h3 class="disp" data-i18n="sing">Sing</h3></div><div class="meta"><b data-i18n="c2">Live singing</b><i>02</i></div><small>Live · Unplugged · Soulful</small></button>
    <button class="card reveal" data-pick="dance"><div class="img"><img src="<?php echo esc_url( MB_URI ); ?>/img/tolerance.jpg" style="object-position:70% 50%" alt="Miss Boldt performing music and movement at the International Day for Tolerance with toll.ev"><span class="go">↗</span><h3 class="disp" data-i18n="dance">Dance</h3></div><div class="meta"><b data-i18n="c3">Storytelling dance</b><i>03</i></div><small data-i18n="c3s">Everyone joins · All ages</small></button>
    <button class="card full reveal" data-pick="full"><div class="img">
      <svg width="150" height="150" viewBox="0 0 150 150" aria-hidden="true"><circle cx="75" cy="75" r="60" fill="none" stroke="rgba(255,255,255,.35)"/><path d="M75 5v20M75 125v20M5 75h20M125 75h20" stroke="rgba(255,255,255,.5)"/><circle cx="75" cy="75" r="36" fill="#f2b84b"/><path d="M62 92c2-20 12-32 28-38-2 18-12 32-28 38z" fill="#86b85c"/></svg>
      <span class="go">↗</span><h3 class="disp">3 in 1</h3></div><div class="meta"><b data-i18n="c4">The full experience</b><i>04</i></div><small data-i18n="c4s">Most booked · 60–90 min</small></button>
  </div>
  <div class="fullbar reveal">
    <div class="n">3/3</div>
    <div><h3 class="disp" data-i18n="fbh">The full <span class="it">ENTER~wellness</span> experience</h3><p data-i18n="fbp">Talk, song and dance in one session. Our most-loved format.</p></div>
    <button class="btn dark" data-pick="full"><span data-i18n="request">Request it</span> →</button>
  </div>
</div></section>

<section class="teaser" id="about"><div class="wrap grid">
  <div class="ph reveal"><img src="<?php echo esc_url( MB_URI ); ?>/img/portrait.jpg" alt="Niomi Boldt"></div>
  <div class="reveal">
    <div class="kicker" data-i18n="aboutTeaserK">Meet Miss Boldt</div>
    <h2 class="disp" data-i18n="aboutTeaserH">Sing, dance <span class="it">&amp; heal</span></h2>
    <p data-i18n="aboutTeaserP">Singer, dancer, speaker and life coach. Turning pain into wisdom, and wisdom into healing, in three languages.</p>
    <div class="statline"><div><b>6<i>+</i></b><small data-i18n="s1">years of healing work</small></div><div><b>3<i>in</i>1</b><small data-i18n="s2">talk, song &amp; dance</small></div><div><b>3</b><small data-i18n="s3">languages: EN · DE · Akan</small></div></div>
    <div class="ctas"><a class="btn solid" href="<?php echo mb_url('about',''); ?>"><span data-i18n="readStory">Read her story</span> →</a><a class="btn ghost" href="<?php echo mb_url('about','talks'); ?>"><span data-i18n="n2">Talks</span></a></div>
  </div>
</div></section>
<section class="coach" id="coach"><div class="wrap grid">
  <div class="tf reveal">
  <figure class="tf-b"><img src="<?php echo esc_url( MB_URI ); ?>/img/before.jpg" alt="Niomi Boldt before her transformation"><figcaption><small data-i18n="before">BEFORE</small><b data-i18n="tfB">Where it started</b></figcaption></figure>
  <div class="tf-mid"><span class="ar">→</span><span class="vt" data-i18n="tfT">TRANSFORMATION</span></div>
  <figure class="tf-a"><img src="<?php echo esc_url( MB_URI ); ?>/img/after.jpg" alt="Niomi Boldt after her transformation"><figcaption><small data-i18n="after">AFTER</small><b data-i18n="tfA">Living it today</b></figcaption></figure>
  <span class="rr"><i>✦</i> <span data-i18n="realRes">REAL RESULT</span></span>
  <div class="q"><span data-i18n="liveWhat">"I live what I teach."</span><small>— MISS BOLDT</small></div>
</div>
  <div class="reveal">
    <div class="kicker" data-i18n="coachK">Wellness coaching</div>
    <h2 class="disp" data-i18n="coachH">Artist <span class="it">who coaches</span></h2>
    <p data-i18n="coachP">Over <b>500 people</b> in Ghana and abroad have walked their wellness journey with her, and she has walked it herself.</p>
    <p class="philo" data-i18n="philo">Natural ways of healing with music and body movement, grounded in nature, belief, lifestyle and celebration.</p>
    <div class="pills"><span data-i18n="p1">Meal planning</span><span data-i18n="p2">Basic exercises</span><span data-i18n="p3">Lifestyle mindset</span><a href="<?php echo mb_url('about','nine'); ?>" data-i18n="p4">9 natural healing methods →</a></div>
    <div class="big500"><div><b>500<i>+</i></b><small data-i18n="b1">people coached</small></div><div><b>GH<i>+</i></b><small data-i18n="b2">Ghana &amp; abroad</small></div><div><b>9</b><small data-i18n="b3">natural healing methods</small></div></div>
    <div class="ctas"><button class="btn solid" data-role="Life coaching"><span data-i18n="startJ">Start your journey</span> →</button><a class="btn ghost" href="<?php echo mb_url('about','coaching'); ?>"><span data-i18n="coachMore">How she coaches</span></a></div>
  </div>
</div></section>
<!-- QUOTE -->
<section class="quote"><div class="wrap reveal">
  <div class="q">“</div>
  <div class="kicker" style="justify-content:center;color:#f1d8ea" data-i18n="k3">In her words</div>
  <blockquote data-i18n="quote">When I <span>sing</span> and <span>dance</span>, I channel healing vibrations to everyone around.</blockquote>
  <div class="who"><img src="<?php echo esc_url( MB_URI ); ?>/img/portrait.jpg" alt="Niomi Boldt (Miss Boldt), singer, dancer and wellness coach, smiling in a purple cap"><div><b>Niomi Boldt</b><small>WELLNESS SPEAKER · SINGER · COACH</small></div></div>
</div></section>

<!-- STAGES -->
<section class="stages">
  <div class="ph"><img src="<?php echo esc_url( MB_URI ); ?>/img/stage.jpg" alt="Niomi Boldt on stage"><em data-i18n="unplug">Live, unplugged, unforgettable.</em></div>
  <div class="tx reveal">
    <div class="kicker" data-i18n="k6">✦ Perfect for</div>
    <h2 class="disp" data-i18n="h2stage">Any stage.<br><span class="it">Any crowd.</span></h2>
    <div class="plist" data-i18n="plist"><span>Wellness retreats</span> <em>✦</em> <span>Festivals</span> <em>✦</em> <span>Tolerance &amp; diversity days</span> <em>✦</em> <span>Schools &amp; youth work</span> <em>✦</em> <span>Corporate wellbeing</span> <em>✦</em> <span>Private celebrations</span> <em>✦</em> <span>Community events</span></div>
    <div class="live"><i></i><span data-i18n="recentLive">Recently on stage at the <b>International Day for Tolerance</b> with toll.ev</span></div>
  </div>
</section>

<!-- WATCH -->
<section class="watch" id="watch"><div class="wrap">
  <div class="head reveal"><div><div class="kicker" data-i18n="k8">Watch</div><h2 class="disp" data-i18n="h2watch">Feel the <span class="it sand">energy</span></h2></div><a class="linkarrow" href="<?php echo mb_url('live',''); ?>"><span data-i18n="seeShows">See all shows</span> →</a></div>
  <div class="swipehint">SWIPE <i></i></div><div class="reels"><?php $mb_x = mb_video_cards( 2, false ); if ( $mb_x ) { echo $mb_x; } else { ?>
    <button class="reel reveal" data-video="0"><img src="<?php echo esc_url( MB_URI ); ?>/img/stage.jpg" style="object-position:50% 40%" alt="Miss Boldt singing live at an unplugged café session"><span class="pb"><svg width="26" height="28"><path d="M3 2l21 12L3 26z" fill="#fff"/></svg></span><span class="cap"><span><small>REEL · SINGING &amp; DANCE</small><h3 class="disp" data-i18n="v1">Live at the café</h3></span><span>573 views</span></span></button>
    <button class="reel reveal" data-video="1"><img src="<?php echo esc_url( MB_URI ); ?>/img/tolerance.jpg" style="object-position:75% 40%" alt="Miss Boldt performing music and movement at the International Day for Tolerance with toll.ev"><span class="pb"><svg width="26" height="28"><path d="M3 2l21 12L3 26z" fill="#fff"/></svg></span><span class="cap"><span><small>REEL · TOLL.EV</small><h3 class="disp" data-i18n="v2">Day for tolerance</h3></span><span>810 views</span></span></button><?php } ?>
  </div>
</div></section>

<!-- RECENT -->
<section class="recent"><div class="wrap">
  <div class="head reveal" style="margin-bottom:30px"><div><div class="kicker" data-i18n="k7">On stage</div><h2 class="disp" data-i18n="h2recent">Recent <span class="it sand">stages</span></h2></div></div>
  <div class="reveal">
    <?php $mb_x = mb_show_rows( 'past', 2 ); if ( $mb_x ) { echo $mb_x; } else { ?><div class="row"><div class="d">16 Nov<small>TOLERANCE DAY</small></div><h4>International Day for Tolerance</h4><p>with toll.ev · Music &amp; movement</p><span class="pill" data-i18n="performed">PERFORMED</span></div>
    <div class="row"><div class="d">Live<small>CAFÉ SESSION</small></div><h4 data-i18n="cafe">Live café performance</h4><p>Singing &amp; dance · Unplugged</p><span class="pill" data-i18n="performed">PERFORMED</span></div>
    <?php } ?><div class="row you"><div class="d" data-i18n="yourDate">Your date<small>2026 · 2027</small></div><h4 data-i18n="yourEv">Your retreat, festival <i>or celebration</i></h4><p data-i18n="ww2">Germany &amp; worldwide · Travel included</p><a class="btn solid" href="<?php echo mb_url('book',''); ?>" style="height:50px" data-i18n="bookNow">Book now</a></div>
  </div>
</div></section>

<a class="nextp" href="<?php echo mb_url('live',''); ?>"><div class="wrap"><div><small data-i18n="nextK">NEXT PAGE</small><h3 class="disp" data-i18n="next1">Live <span class="it">&amp; music</span></h3></div><span class="arr">→</span></div></a>
<!-- CTA -->
<section class="cta"><div class="wrap reveal">
  <h2 class="disp" data-i18n="h2cta">Let's make<br>something <span class="it">healing</span></h2>
  <div class="bot"><a class="mail" href="mailto:<?php echo esc_attr( mb_opt( 'mb_email', 'niomiboldt@gmail.com' ) ); ?>"><?php echo esc_html( mb_opt( 'mb_email', 'niomiboldt@gmail.com' ) ); ?> <button class="copy" type="button" id="copyMail" data-i18n="copy">COPY</button></a><a class="btn solid" href="<?php echo mb_url('book',''); ?>"><span data-i18n="checkDates">Check dates</span> →</a></div>
</div></section>
<?php get_footer();
