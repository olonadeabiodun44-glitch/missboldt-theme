<?php
/**
 * Miss Boldt · ENTER~wellness theme
 */
if ( ! defined( 'ABSPATH' ) ) exit;
define( 'MB_VER', '1.1.11' );
define( 'MB_URI', get_template_directory_uri() );
require get_template_directory() . '/inc/content.php';
require get_template_directory() . '/inc/booking.php';
require get_template_directory() . '/inc/setup.php';
require get_template_directory() . '/inc/updater.php';
require get_template_directory() . '/inc/seo.php';

add_action( 'after_setup_theme', function () {
	add_theme_support( 'title-tag' );
	add_theme_support( 'post-thumbnails' );
	add_theme_support( 'html5', array( 'script', 'style' ) );
} );

add_filter( 'document_title_separator', function () { return '·'; } );
add_filter( 'document_title_parts', function ( $p ) {
	if ( is_front_page() ) { $p['title'] = 'Miss Boldt'; $p['tagline'] = 'ENTER~wellness'; }
	return $p;
} );

/* which page are we on (used by the menu highlight) */
function mb_page() {
	if ( is_front_page() ) return 'home';
	if ( is_page( 'live' ) ) return 'live';
	if ( is_page( 'about' ) ) return 'about';
	if ( is_page( 'book' ) ) return 'book';
	return 'other';
}
function mb_url( $slug = '', $hash = '' ) {
	$u = $slug ? home_url( '/' . $slug . '/' ) : home_url( '/' );
	return esc_url( $u . ( $hash ? '#' . $hash : '' ) );
}
function mb_opt( $key, $default = '' ) {
	$v = get_theme_mod( $key, $default );
	return $v === '' ? $default : $v;
}

add_action( 'wp_enqueue_scripts', function () {
	wp_enqueue_style( 'mb-style', MB_URI . '/assets/style.css', array(), MB_VER );
	wp_enqueue_style( 'mb-fx', MB_URI . '/assets/fx.css', array( 'mb-style' ), MB_VER );
	wp_enqueue_script( 'mb-app', MB_URI . '/assets/app.js', array(), MB_VER, true );
	wp_enqueue_script( 'mb-fx', MB_URI . '/assets/fx.js', array( 'mb-app' ), MB_VER, true );
	wp_add_inline_script( 'mb-app', 'window.MB_CFG=' . wp_json_encode( array(
		'ajax'   => admin_url( 'admin-ajax.php' ),
		'nonce'  => wp_create_nonce( 'mb_booking' ),
		'book'   => home_url( '/book/' ),
		'email'  => mb_opt( 'mb_email', 'niomiboldt@gmail.com' ),
		'booked' => mb_booked_dates(),
	) ) . ';', 'before' );
} );

/* small extras in <head> */
add_action( 'wp_head', function () {
	$desc = mb_seo_desc();
	echo '<meta name="description" content="' . esc_attr( $desc ) . '">' . "\n";
	echo '<meta property="og:title" content="' . esc_attr( wp_get_document_title() ) . '">' . "\n";
	echo '<meta property="og:description" content="' . esc_attr( $desc ) . '">' . "\n";
	$img = MB_URI . '/img/share.jpg?v=' . MB_VER;
	echo '<meta property="og:image" content="' . esc_url( $img ) . '">' . "\n";
	echo '<meta property="og:image:width" content="1200"><meta property="og:image:height" content="630">' . "\n";
	echo '<meta property="og:image:alt" content="Miss Boldt · ENTER~wellness logo">' . "\n";
	echo '<meta property="og:url" content="' . esc_url( home_url( add_query_arg( array() ) ) ) . '">' . "\n";
	echo '<meta property="og:site_name" content="Miss Boldt">' . "\n";
	echo '<meta name="twitter:card" content="summary_large_image"><meta name="twitter:image" content="' . esc_url( $img ) . '">' . "\n";
	if ( ! has_site_icon() ) {
		echo '<link rel="icon" type="image/png" sizes="32x32" href="' . esc_url( MB_URI . '/img/favicon-32.png' ) . '">' . "\n";
		echo '<link rel="icon" type="image/png" sizes="512x512" href="' . esc_url( MB_URI . '/img/icon-512.png' ) . '">' . "\n";
		echo '<link rel="apple-touch-icon" href="' . esc_url( MB_URI . '/img/apple-touch-icon.png' ) . '">' . "\n";
	}
	echo '<meta property="og:type" content="website">' . "\n";
	echo '<style>.admin-bar nav#nav{top:32px}@media(max-width:782px){.admin-bar nav#nav{top:46px}}</style>' . "\n";
}, 5 );

/* Customizer: contact + social links + blocked dates */
add_action( 'customize_register', function ( $c ) {
	$c->add_section( 'mb_contact', array( 'title' => 'Miss Boldt: contact & booking', 'priority' => 30 ) );
	$fields = array(
		'mb_email'         => array( 'Public email (shown on the site)', 'niomiboldt@gmail.com', 'email' ),
		'mb_booking_email' => array( 'Send booking requests to', 'niomiboldt@gmail.com', 'email' ),
		'mb_facebook'      => array( 'Facebook link', '', 'url' ),
		'mb_instagram'     => array( 'Instagram link', '', 'url' ),
		'mb_youtube'       => array( 'YouTube link', '', 'url' ),
		'mb_blocked'       => array( 'Booked / unavailable dates (one per line, YYYY-MM-DD)', '', 'textarea' ),
	);
	foreach ( $fields as $id => $f ) {
		$c->add_setting( $id, array( 'default' => $f[1], 'sanitize_callback' => $f[2] === 'email' ? 'sanitize_email' : ( $f[2] === 'url' ? 'esc_url_raw' : 'sanitize_textarea_field' ) ) );
		$c->add_control( $id, array( 'label' => $f[0], 'section' => 'mb_contact', 'type' => $f[2] === 'textarea' ? 'textarea' : 'text' ) );
	}
} );

/* One address for everyone: send old/temporary hosts and plain http to https://<main domain> */
add_action( 'template_redirect', function () {
	if ( is_admin() || wp_doing_ajax() || wp_doing_cron() || ( defined( 'REST_REQUEST' ) && REST_REQUEST ) ) return;
	$home = wp_parse_url( home_url() );
	if ( empty( $home['host'] ) ) return;
	$host = isset( $_SERVER['HTTP_HOST'] ) ? strtolower( preg_replace( '/:\d+$/', '', $_SERVER['HTTP_HOST'] ) ) : '';
	$secure = is_ssl()
		|| ( isset( $_SERVER['HTTP_X_FORWARDED_PROTO'] ) && 'https' === strtolower( $_SERVER['HTTP_X_FORWARDED_PROTO'] ) )
		|| ( isset( $_SERVER['HTTP_X_FORWARDED_SSL'] ) && 'on' === strtolower( $_SERVER['HTTP_X_FORWARDED_SSL'] ) )
		|| ( isset( $_SERVER['SERVER_PORT'] ) && 443 === (int) $_SERVER['SERVER_PORT'] );
	$want_https = ( 'https' === ( $home['scheme'] ?? '' ) );
	if ( $host && ( $host !== strtolower( $home['host'] ) || ( $want_https && ! $secure ) ) ) {
		$uri = isset( $_SERVER['REQUEST_URI'] ) ? $_SERVER['REQUEST_URI'] : '/';
		wp_redirect( ( $want_https ? 'https' : 'http' ) . '://' . $home['host'] . $uri, 301 );
		exit;
	}
}, 1 );

/* Pages are always re-checked by browsers, so visitors never see an old saved copy after changes */
add_action( 'send_headers', function () {
	if ( is_admin() ) return;
	header( 'Cache-Control: no-cache, must-revalidate, max-age=0' );
	header_remove( 'Expires' );
}, 99 );
