<?php
/* page-book */
get_header(); ?>
<section class="phero"><div class="pnum">04</div><div class="wrap">
  <div class="reveal">
    <div class="crumb"><a href="<?php echo mb_url('',''); ?>" data-i18n="crHome">Home</a> <span>/</span> <b data-i18n="nBook">Book</b></div>
    <h1 class="disp" data-i18n="bookH1">Book <span class="it">Miss Boldt</span></h1>
    <p class="lead" data-i18n="bookLead">Pick a date, share your event and get a personal proposal. Free and non-binding.</p>
    <div class="ctas"><a class="btn solid" href="<?php echo mb_url('book','book'); ?>"><span data-i18n="checkDates">Check dates</span> ↓</a><a class="btn ghost" href="<?php echo mb_url('book','faq'); ?>">FAQ</a></div>
  </div>
  <div class="collage reveal"><div class="sunlet"></div><div class="c c1"><img src="<?php echo esc_url( MB_URI ); ?>/img/portrait.jpg" style="object-position:50% 10%" alt="Niomi Boldt (Miss Boldt), singer, dancer and wellness coach, smiling in a purple cap"></div><div class="c c2"><img src="<?php echo esc_url( MB_URI ); ?>/img/stage.jpg" style="object-position:50% 40%" alt="Miss Boldt singing live at an unplugged café session"></div></div>
</div></section>
<!-- BOOKING -->
<section class="book light" id="book"><div class="wrap">
  <div class="head reveal" style="margin-bottom:44px">
    <div><div class="kicker" data-i18n="n6">Booking</div><h2 class="disp" data-i18n="h2book">Book <span class="it orchid">Miss Boldt</span></h2></div>
    <p data-i18n="pbook">Free and non-binding. A personal reply with plan and quote.</p>
  </div>
  <div class="steps reveal">
    <div class="step"><span class="c">01</span><div><h4 data-i18n="st1">Choose your date</h4><p data-i18n="st1p">Open dates, right on the calendar.</p></div></div>
    <div class="step"><span class="c">02</span><div><h4 data-i18n="st2">Share your event</h4><p data-i18n="st2p">Where, who and what. Two minutes.</p></div></div>
    <div class="step"><span class="c">03</span><div><h4 data-i18n="st3">Get your proposal</h4><p data-i18n="st3p">Tailored plan and quote, travel included.</p></div></div>
  </div>
  <div class="info3 reveal"><div><i>✈</i><span><b data-i18n="i1">Travel included</b><small data-i18n="i1p">Germany &amp; worldwide</small></span></div><div><i>✓</i><span><b data-i18n="i2">Free &amp; non-binding</b><small data-i18n="i2p">Get a proposal, then decide</small></span></div><div><i>♡</i><span><b data-i18n="i3">Personal reply</b><small data-i18n="i3p">Straight from Miss Boldt</small></span></div></div>
  <div class="bgrid" style="margin-top:40px">
    <div class="cal reveal">
      <div class="top"><button class="nb" id="calPrev" aria-label="Previous month">‹</button><h4 id="calTitle">Month</h4><button class="nb" id="calNext" aria-label="Next month">›</button></div>
      <div class="days" id="days"></div>
      <div class="legend"><span><i style="background:var(--plum3)"></i><span data-i18n="open">Open</span></span><span><i style="border:1px solid #6d5468"></i><span data-i18n="booked">Booked</span></span><span><i style="background:var(--gold)"></i><span data-i18n="yours">Your date</span></span></div>
      <div class="travel"><i>✈</i><span data-i18n="calTravel"><b>Ready to travel.</b> Germany and worldwide. Travel is included in your proposal.</span></div>
    </div>

    <form class="form reveal" id="form" novalidate>
      <div class="prog"><i class="on"></i><i></i><i></i></div>
      <!-- step 1 -->
      <div class="pane on" data-step="1">
        <div class="stp" data-i18n="s1of3">Step 1 of 3 · Your event</div>
        <h4 data-i18n="fh1">Your event</h4>
        <div class="f2">
          <div class="fld"><label for="fDate" data-i18n="lDate">Event date</label><input type="date" id="fDate" name="date" required><div class="msg" data-i18n="eDate">Please choose a date.</div></div>
          <div class="fld"><label for="fCity" data-i18n="lCity">City &amp; country</label><input id="fCity" name="city" placeholder="e.g. Berlin, Germany" required><div class="msg" data-i18n="eReq">Please fill this in.</div></div>
          <div class="fld"><label for="fType" data-i18n="lType">Type of event</label><select id="fType" name="type" required><option value="">Choose…</option><option>Wellness retreat</option><option>Festival</option><option>Tolerance / diversity day</option><option>School / youth work</option><option>Corporate wellbeing</option><option>Private celebration</option><option>Community event</option><option>Other</option></select><div class="msg" data-i18n="ePick">Please choose one.</div></div>
          <div class="fld"><label for="fGuests" data-i18n="lGuests">Expected guests</label><select id="fGuests" name="guests" required><option value="">Choose…</option><option>Under 50</option><option>50–150</option><option>150–500</option><option>500+</option></select><div class="msg" data-i18n="ePick">Please choose one.</div></div>
        </div>
        <div class="foot"><small data-i18n="free">Free · Non-binding · Personal reply</small><div class="bt"><button type="button" class="btn dark" data-next><span data-i18n="cont">Continue</span> →</button></div></div>
      </div>
      <!-- step 2 -->
      <div class="pane" data-step="2">
        <div class="stp" data-i18n="s2of3">Step 2 of 3 · The experience</div>
        <h4 data-i18n="fh2">What would you love?</h4>
        <div class="fld" id="fldX"><span class="lb" data-i18n="lExp">Choose one or more</span>
          <div class="xgrid opts" id="xgrid">
            <button type="button" class="xopt" data-v="talk"><span class="bx">✓</span><span><b data-i18n="c1">Wellness talk</b><small>20–45 min</small></span></button>
            <button type="button" class="xopt" data-v="sing"><span class="bx">✓</span><span><b data-i18n="c2">Live singing</b><small>Unplugged · Soulful</small></span></button>
            <button type="button" class="xopt" data-v="dance"><span class="bx">✓</span><span><b data-i18n="c3">Storytelling dance</b><small data-i18n="c3s">Everyone joins · All ages</small></span></button>
            <button type="button" class="xopt" data-v="full"><span class="bx">✓</span><span><b data-i18n="c4">The full experience</b><small>3 in 1 · 60–90 min</small></span></button>
          </div><div class="msg" data-i18n="eExp">Please choose at least one.</div></div>
        <div class="fld"><span class="lb" data-i18n="lTopic">Talk topic (optional)</span>
          <div class="opts" id="topics"><button type="button" class="opt">Healing from trauma</button><button type="button" class="opt">Healthy lifestyle</button><button type="button" class="opt">Purpose in life</button><button type="button" class="opt">Forgiveness &amp; tolerance</button><button type="button" class="opt">Accountability</button><button type="button" class="opt">Building a dream life</button></div></div>
        <div class="fld"><span class="lb" data-i18n="lMethods">Healing methods (optional)</span>
          <div class="opts" id="methods"><button type="button" class="opt">Dance to heal</button><button type="button" class="opt">Sing to heal</button><button type="button" class="opt">Be a child to heal</button><button type="button" class="opt">Speak to heal</button><button type="button" class="opt">Eat to heal</button><button type="button" class="opt">Fitness & flexibility</button><button type="button" class="opt">Self care & love</button><button type="button" class="opt">Believe to heal</button><button type="button" class="opt">Celebrate to heal</button></div></div>
        <div class="fld"><span class="lb" data-i18n="lAlso">Also interested in (optional)</span>
          <div class="opts" id="extras"><button type="button" class="opt">Life coaching</button><button type="button" class="opt">Speaking</button><button type="button" class="opt">Songwriting</button><button type="button" class="opt">Storytelling dance</button><button type="button" class="opt">Author</button><button type="button" class="opt">Acting</button><button type="button" class="opt">Modelling</button><button type="button" class="opt">Event planning</button></div></div>
        <div class="fld"><span class="lb" data-i18n="lLang">Language</span>
          <div class="opts" id="langs" data-single><button type="button" class="opt on">English</button><button type="button" class="opt">Deutsch</button><button type="button" class="opt">Akan (Twi/Fanti)</button><button type="button" class="opt">Mixed</button></div></div>
        <div class="foot"><button type="button" class="btn line" data-back>← <span data-i18n="back">Back</span></button><div class="bt"><button type="button" class="btn dark" data-next><span data-i18n="cont">Continue</span> →</button></div></div>
      </div>
      <!-- step 3 -->
      <div class="pane" data-step="3">
        <div class="stp" data-i18n="s3of3">Step 3 of 3 · Your details</div>
        <h4 data-i18n="fh3">Who should she reply to?</h4>
        <div class="f2">
          <div class="fld"><label for="fName" data-i18n="lName">Your name</label><input id="fName" name="name" autocomplete="name" required><div class="msg" data-i18n="eReq">Please fill this in.</div></div>
          <div class="fld"><label for="fOrg" data-i18n="lOrg">Organisation (optional)</label><input id="fOrg" name="org" autocomplete="organization"></div>
          <div class="fld"><label for="fEmail" data-i18n="lEmail">Email</label><input id="fEmail" type="email" name="email" autocomplete="email" required><div class="msg" data-i18n="eEmail">Please enter a valid email.</div></div>
          <div class="fld"><label for="fPhone" data-i18n="lPhone">Phone / WhatsApp (optional)</label><input id="fPhone" type="tel" name="phone" autocomplete="tel"></div>
        </div>
        <div class="fld"><label for="fMsg" data-i18n="lMsg">Anything else? (optional)</label><textarea id="fMsg" name="msg" placeholder="Theme, schedule, questions…"></textarea></div>
        <div class="foot"><button type="button" class="btn line" data-back>← <span data-i18n="back">Back</span></button><div class="bt"><button type="submit" class="btn solid"><span data-i18n="send">Send request</span> →</button></div></div>
      </div>
      <!-- done -->
      <div class="pane" data-step="4">
        <div class="done">
          <div class="tick">✓</div>
          <h4 data-i18n="thx">Thank you!</h4>
          <p style="color:#5f4a59" data-i18n="thxp">Here is your request. Send it to Miss Boldt by email and she will reply personally with a tailored plan and quote.</p>
          <div class="sum" id="sum"></div>
          <div class="bt"><a class="btn solid" id="mailBtn" href="#"><span data-i18n="emailIt">Email this request</span> →</a><button type="button" class="btn line" id="copyReq" data-i18n="copyReq">Copy request</button></div>
          <p class="note"><span data-i18n="mailNote">Email opens your mail app, addressed to</span> <b><?php echo esc_html( mb_opt( 'mb_email', 'niomiboldt@gmail.com' ) ); ?></b>.</p>
          <p class="note"><button type="button" id="newReq" style="text-decoration:underline" data-i18n="newReq">Start a new request</button></p>
        </div>
      </div>
    </form>
  </div>
</div></section>

<!-- FAQ -->
<section class="faq" id="faq"><div class="wrap grid">
  <aside class="reveal"><div class="kicker">FAQ</div><h2 class="disp" data-i18n="h2faq">Good to <span class="it">know</span></h2><p data-i18n="pfaq">Another question? Add it to your request.</p></aside>
  <div class="qa reveal">
    <div class="qi open"><button><i>01</i><span class="q" data-i18n="q1" style="all:unset">Do you travel for events?</span><span>+</span></button><div class="ans"><div><p data-i18n="a1">Yes. Across Germany and worldwide. Travel is included in every quote.</p></div></div></div>
    <div class="qi"><button><i>02</i><span data-i18n="q2" style="all:unset">Which languages do you perform in?</span><span>+</span></button><div class="ans"><div><p data-i18n="a2">English, German and Akan (Twi/Fanti), her mother tongue from Ghana. Talks can mix languages for diverse audiences.</p></div></div></div>
    <div class="qi"><button><i>03</i><span data-i18n="q3" style="all:unset">How long is a performance?</span><span>+</span></button><div class="ans"><div><p data-i18n="a3">A talk runs 20–45 minutes. The full 3-in-1 experience runs 60–90 minutes. Everything can be adjusted.</p></div></div></div>
    <div class="qi"><button><i>04</i><span data-i18n="q4" style="all:unset">Can the talk match our theme?</span><span>+</span></button><div class="ans"><div><p data-i18n="a4">Yes. Pick one of her six topics or share your theme, and she tailors the talk to it.</p></div></div></div>
    <div class="qi"><button><i>05</i><span data-i18n="q5" style="all:unset">Is sending a request binding?</span><span>+</span></button><div class="ans"><div><p data-i18n="a5">No. It is free and non-binding. You receive a personal proposal first.</p></div></div></div>
  </div>
</div></section>

<!-- CTA -->
<section class="cta"><div class="wrap reveal">
  <h2 class="disp" data-i18n="h2cta">Let's make<br>something <span class="it">healing</span></h2>
  <div class="bot"><a class="mail" href="mailto:<?php echo esc_attr( mb_opt( 'mb_email', 'niomiboldt@gmail.com' ) ); ?>"><?php echo esc_html( mb_opt( 'mb_email', 'niomiboldt@gmail.com' ) ); ?> <button class="copy" type="button" id="copyMail" data-i18n="copy">COPY</button></a><a class="btn solid" href="#book"><span data-i18n="checkDates">Check dates</span> →</a></div>
</div></section>

<a class="nextp" href="<?php echo mb_url('',''); ?>"><div class="wrap"><div><small data-i18n="nextK">NEXT PAGE</small><h3 class="disp" data-i18n="next4">Back to <span class="it">home</span></h3></div><span class="arr">→</span></div></a>
<?php get_footer();
