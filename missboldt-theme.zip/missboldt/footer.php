<footer><div class="wrap">
  <div class="cols">
    <div><a class="logo" href="<?php echo mb_url('',''); ?>"><span class="mark">B</span><span><div class="name">Miss Boldt</div><div class="sub">ENTER~WELLNESS</div></span></a><p class="bio" data-i18n="bio">Singer, dancer, speaker and life coach. Bringing ENTER~wellness to events in Germany and worldwide.</p></div>
    <div><h5 data-i18n="explore">EXPLORE</h5><ul><li><a href="<?php echo mb_url('',''); ?>" data-i18n="nHome">Home</a></li><li><a href="<?php echo mb_url('live',''); ?>" data-i18n="nLive">Live &amp; Music</a></li><li><a href="<?php echo mb_url('about',''); ?>" data-i18n="nAbout">About &amp; Talks</a></li><li><a href="<?php echo mb_url('about','talks'); ?>" data-i18n="n2">Talks</a></li></ul></div>
    <div><h5 data-i18n="bookings">BOOKING</h5><ul><li><a href="<?php echo mb_url('book',''); ?>" data-i18n="checkDates">Check dates</a></li><li><a href="<?php echo mb_url('book','faq'); ?>">FAQ</a></li><li><a href="mailto:<?php echo esc_attr( mb_opt( 'mb_email', 'niomiboldt@gmail.com' ) ); ?>">Email</a></li></ul></div>
    <div><h5 data-i18n="follow">FOLLOW</h5><ul><li><a href="<?php echo esc_url( mb_opt( 'mb_facebook', 'https://www.facebook.com/' ) ); ?>" target="_blank" rel="noopener">Facebook</a></li><li><a href="<?php echo esc_url( mb_opt( 'mb_instagram', 'https://www.instagram.com/' ) ); ?>" target="_blank" rel="noopener">Instagram</a></li></ul><div class="tag">#healingwithniomiboldt</div></div>
  </div>
  <div class="outline">MISS BOLDT</div>
  <div class="legal"><span>© 2026 Niomi Boldt · ENTER~wellness</span><span><a href="#" data-modal="legal">Impressum</a> &nbsp;·&nbsp; <a href="#" data-modal="legal">Privacy</a></span></div>
</div></footer>
<!-- video modal -->
<div class="modal" id="vmodal" role="dialog" aria-modal="true">
  <div class="mbox">
    <button class="close" data-close aria-label="Close">✕</button>
    <div class="vid"><img id="vimg" src="<?php echo esc_url( MB_URI ); ?>/img/stage.jpg" alt=""><div class="msg"><b id="vtitle">Live at the café</b><span data-i18n="vmsg">Miss Boldt's performance video plays here once it is uploaded.</span></div></div>
    <div class="mf"><span style="color:var(--muted)" data-i18n="vlike">Like what you see?</span><a class="btn solid" href="<?php echo mb_url('book',''); ?>" data-close><span data-i18n="bring">Bring this to your event</span> →</a></div>
  </div>
</div>
<div class="modal" id="lmodal" role="dialog" aria-modal="true">
  <div class="mbox" style="max-width:560px;padding:44px 36px">
    <button class="close" data-close aria-label="Close">✕</button>
    <h3 class="disp" style="font-size:30px;margin-bottom:16px">Impressum &amp; Privacy</h3>
    <p style="color:var(--muted)" data-i18n="legal">Legal notice and privacy policy will be added before the site goes live.</p>
  </div>
</div>
<div class="toast" id="toast"></div>
<button class="totop" id="totop" aria-label="Back to top">↑</button>
<div class="mcta" id="mcta"><span><b>Miss Boldt</b><span data-i18n="i2">Free &amp; non-binding</span></span><a class="btn solid" href="<?php echo mb_url('book',''); ?>"><span data-i18n="checkDates">Check dates</span> →</a></div>
<div class="lb" id="lb" role="dialog" aria-modal="true"><img id="lbImg" alt=""><div class="cap" id="lbCap"></div><button class="x" id="lbX" aria-label="Close">✕</button><button class="lp" id="lbPrev" aria-label="Previous">←</button><button class="ln" id="lbNext" aria-label="Next">→</button></div>
<?php wp_footer(); ?>
</body>
</html>
