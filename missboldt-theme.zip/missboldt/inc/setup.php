<?php
/**
 * On activation: create the pages, set the home page and clean links.
 */
if ( ! defined( 'ABSPATH' ) ) exit;

function mb_setup_site() {
	$pages = array( 'home' => 'Home', 'live' => 'Live & Music', 'about' => 'About & Talks', 'book' => 'Book' );
	$ids = array();
	foreach ( $pages as $slug => $title ) {
		$p = get_page_by_path( $slug );
		$ids[ $slug ] = $p ? $p->ID : wp_insert_post( array( 'post_type' => 'page', 'post_status' => 'publish', 'post_title' => $title, 'post_name' => $slug ) );
	}
	update_option( 'show_on_front', 'page' );
	update_option( 'page_on_front', $ids['home'] );
	if ( ! get_option( 'permalink_structure' ) ) update_option( 'permalink_structure', '/%postname%/' );
	update_option( 'blogname', 'Miss Boldt' );
	update_option( 'blogdescription', 'ENTER~wellness' );
	flush_rewrite_rules();
}
add_action( 'after_switch_theme', function () { mb_setup_site(); set_transient( 'mb_welcome', 1, DAY_IN_SECONDS ); } );

add_action( 'admin_notices', function () {
	if ( ! get_transient( 'mb_welcome' ) || ! current_user_can( 'manage_options' ) ) return;
	echo '<div class="notice notice-success is-dismissible"><p><strong>Miss Boldt theme is ready.</strong> Add content from the menu on the left: <b>Videos</b>, <b>Songs</b>, <b>Shows</b>, <b>Gallery</b>, <b>Testimonials</b>. Booking requests arrive under <b>Booking requests</b> and by email. Contact details and booked dates: <a href="' . esc_url( admin_url( 'customize.php?autofocus[section]=mb_contact' ) ) . '">Appearance → Customize → Miss Boldt: contact &amp; booking</a>.</p></div>';
} );
