<?php
/**
 * Content types Miss Boldt can manage in the WordPress admin:
 * Videos, Songs, Shows, Gallery photos and Testimonials.
 */
if ( ! defined( 'ABSPATH' ) ) exit;

function mb_types() {
	return array(
		'mb_video' => array( 'Videos', 'Video', 'dashicons-video-alt3', array( 'title', 'thumbnail', 'page-attributes' ), array(
			'mb_youtube' => array( 'YouTube link (recommended)', 'url', 'Paste the YouTube address, e.g. https://www.youtube.com/watch?v=…' ),
			'mb_file'    => array( 'Or upload a short video file (MP4)', 'media:video', 'Large videos are better on YouTube.' ),
			'mb_cat'     => array( 'Category', 'select:music=Live music|dance=Dance|talks=Talk', '' ),
			'mb_sub'     => array( 'Small label above the title', 'text', 'e.g. REEL · SINGING & DANCE' ),
			'mb_dur'     => array( 'Length', 'text', 'e.g. 2:15' ),
		), 'Cover image: set the “Featured image”. If empty, the YouTube thumbnail is used.' ),
		'mb_song' => array( 'Songs', 'Song', 'dashicons-format-audio', array( 'title', 'page-attributes' ), array(
			'mb_mp3' => array( 'Song file (MP3)', 'media:audio', 'Upload or choose the MP3 from the Media Library.' ),
			'mb_sub' => array( 'Small line under the title', 'text', 'e.g. Live at the café' ),
		), 'The first song (lowest “Order”) also plays in the bar on the Home page.' ),
		'mb_show' => array( 'Shows', 'Show', 'dashicons-calendar-alt', array( 'title' ), array(
			'mb_date'    => array( 'Date', 'date', 'Upcoming dates are also marked as booked on the booking calendar.' ),
			'mb_label'   => array( 'Small label under the date', 'text', 'e.g. TOLERANCE DAY' ),
			'mb_details' => array( 'Details', 'text', 'e.g. with toll.ev · Music & movement' ),
		), '' ),
		'mb_photo' => array( 'Gallery', 'Photo', 'dashicons-format-gallery', array( 'title', 'thumbnail', 'page-attributes' ), array(), 'Set the photo as the “Featured image”. The title is shown as the caption.' ),
		'mb_testimonial' => array( 'Testimonials', 'Testimonial', 'dashicons-format-quote', array( 'title', 'page-attributes' ), array(
			'mb_quote' => array( 'Quote', 'textarea', 'What the guest or organiser said.' ),
			'mb_role'  => array( 'Role / event', 'text', 'e.g. Wellness retreat organiser' ),
		), 'Title = the person’s name.' ),
	);
}

add_action( 'init', function () {
	foreach ( mb_types() as $type => $t ) {
		register_post_type( $type, array(
			'labels' => array(
				'name' => $t[0], 'singular_name' => $t[1], 'add_new' => 'Add ' . $t[1], 'add_new_item' => 'Add ' . $t[1],
				'edit_item' => 'Edit ' . $t[1], 'all_items' => 'All ' . $t[0], 'menu_name' => $t[0],
			),
			'public' => false, 'show_ui' => true, 'show_in_menu' => true, 'menu_icon' => $t[2],
			'supports' => $t[3], 'menu_position' => 21,
		) );
	}
} );

/* ---------- meta boxes ---------- */
add_action( 'add_meta_boxes', function () {
	foreach ( mb_types() as $type => $t ) {
		if ( empty( $t[4] ) && ! $t[5] ) continue;
		add_meta_box( 'mb_fields', 'Details', 'mb_render_box', $type, 'normal', 'high' );
	}
} );
function mb_render_box( $post ) {
	$t = mb_types()[ $post->post_type ];
	wp_nonce_field( 'mb_save', 'mb_nonce' );
	if ( $t[5] ) echo '<p style="background:#fbf3e4;border-left:3px solid #f2b84b;padding:8px 12px">' . esc_html( $t[5] ) . '</p>';
	echo '<table class="form-table">';
	foreach ( $t[4] as $key => $f ) {
		$val = get_post_meta( $post->ID, $key, true );
		echo '<tr><th><label for="' . esc_attr( $key ) . '">' . esc_html( $f[0] ) . '</label></th><td>';
		if ( strpos( $f[1], 'select:' ) === 0 ) {
			echo '<select name="' . esc_attr( $key ) . '" id="' . esc_attr( $key ) . '">';
			foreach ( explode( '|', substr( $f[1], 7 ) ) as $o ) { list( $v, $l ) = explode( '=', $o ); echo '<option value="' . esc_attr( $v ) . '"' . selected( $val, $v, false ) . '>' . esc_html( $l ) . '</option>'; }
			echo '</select>';
		} elseif ( $f[1] === 'textarea' ) {
			echo '<textarea class="large-text" rows="4" name="' . esc_attr( $key ) . '" id="' . esc_attr( $key ) . '">' . esc_textarea( $val ) . '</textarea>';
		} elseif ( strpos( $f[1], 'media:' ) === 0 ) {
			echo '<input type="url" class="regular-text" name="' . esc_attr( $key ) . '" id="' . esc_attr( $key ) . '" value="' . esc_attr( $val ) . '"> ';
			echo '<button type="button" class="button mb-media" data-target="' . esc_attr( $key ) . '" data-kind="' . esc_attr( substr( $f[1], 6 ) ) . '">Upload / choose file</button>';
		} else {
			$type = $f[1] === 'date' ? 'date' : ( $f[1] === 'url' ? 'url' : 'text' );
			echo '<input type="' . $type . '" class="regular-text" name="' . esc_attr( $key ) . '" id="' . esc_attr( $key ) . '" value="' . esc_attr( $val ) . '">';
		}
		if ( $f[2] ) echo '<p class="description">' . esc_html( $f[2] ) . '</p>';
		echo '</td></tr>';
	}
	echo '</table>';
}
add_action( 'save_post', function ( $id ) {
	if ( ! isset( $_POST['mb_nonce'] ) || ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['mb_nonce'] ) ), 'mb_save' ) ) return;
	if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) return;
	if ( ! current_user_can( 'edit_post', $id ) ) return;
	$type = get_post_type( $id ); $types = mb_types();
	if ( ! isset( $types[ $type ] ) ) return;
	foreach ( $types[ $type ][4] as $key => $f ) {
		if ( ! isset( $_POST[ $key ] ) ) continue;
		$raw = wp_unslash( $_POST[ $key ] );
		$val = ( $f[1] === 'url' || strpos( $f[1], 'media:' ) === 0 ) ? esc_url_raw( $raw ) : ( $f[1] === 'textarea' ? sanitize_textarea_field( $raw ) : sanitize_text_field( $raw ) );
		update_post_meta( $id, $key, $val );
	}
} );
add_action( 'admin_enqueue_scripts', function ( $hook ) {
	if ( ! in_array( $hook, array( 'post.php', 'post-new.php' ), true ) ) return;
	wp_enqueue_media();
	wp_add_inline_script( 'jquery-core', "jQuery(function($){\$(document).on('click','.mb-media',function(e){e.preventDefault();var b=\$(this),f=wp.media({title:'Choose file',library:{type:b.data('kind')},multiple:false});f.on('select',function(){var a=f.state().get('selection').first().toJSON();\$('#'+b.data('target')).val(a.url)});f.open()})});" );
} );

/* ---------- helpers used by the templates ---------- */
function mb_posts( $type, $args = array() ) {
	return get_posts( array_merge( array( 'post_type' => $type, 'numberposts' => -1, 'post_status' => 'publish', 'orderby' => array( 'menu_order' => 'ASC', 'date' => 'DESC' ) ), $args ) );
}
function mb_yt_id( $url ) {
	if ( preg_match( '~(?:youtu\.be/|v=|embed/|shorts/|live/)([A-Za-z0-9_-]{11})~', (string) $url, $m ) ) return $m[1];
	return '';
}
function mb_video_cards( $limit = -1, $wide_first = true ) {
	$vids = mb_posts( 'mb_video', array( 'numberposts' => $limit ) );
	if ( ! $vids ) return '';
	$cats = array( 'music' => 'LIVE MUSIC', 'dance' => 'DANCE', 'talks' => 'TALK' );
	$out = '';
	foreach ( $vids as $i => $v ) {
		$yt = mb_yt_id( get_post_meta( $v->ID, 'mb_youtube', true ) );
		$mp4 = get_post_meta( $v->ID, 'mb_file', true );
		$cat = get_post_meta( $v->ID, 'mb_cat', true ) ?: 'music';
		$img = get_the_post_thumbnail_url( $v, 'large' );
		if ( ! $img && $yt ) $img = 'https://i.ytimg.com/vi/' . $yt . '/hqdefault.jpg';
		if ( ! $img ) $img = MB_URI . '/img/stage.jpg';
		$sub = get_post_meta( $v->ID, 'mb_sub', true );
		$dur = get_post_meta( $v->ID, 'mb_dur', true );
		$title = get_the_title( $v );
		$out .= '<button class="reel reveal' . ( $wide_first && $i === 0 ? ' wide' : '' ) . '" data-cat="' . esc_attr( $cat ) . '" data-video="1" data-title="' . esc_attr( $title ) . '"'
			. ( $yt ? ' data-yt="' . esc_attr( $yt ) . '"' : '' ) . ( $mp4 ? ' data-mp4="' . esc_url( $mp4 ) . '"' : '' ) . '>'
			. '<img src="' . esc_url( $img ) . '" alt="' . esc_attr( 'Video: ' . $title . ' · Miss Boldt' ) . '" loading="lazy"><span class="tag">' . esc_html( $cats[ $cat ] ?? 'VIDEO' ) . '</span>'
			. ( $dur ? '<span class="dur">' . esc_html( $dur ) . '</span>' : '' )
			. '<span class="pb"><svg width="26" height="28"><path d="M3 2l21 12L3 26z" fill="#fff"/></svg></span>'
			. '<span class="cap"><span><small>' . esc_html( $sub ) . '</small><h3 class="disp">' . esc_html( $title ) . '</h3></span></span></button>';
	}
	return $out;
}
function mb_song_rows() {
	$songs = mb_posts( 'mb_song' );
	if ( ! $songs ) return '';
	$out = '';
	foreach ( $songs as $i => $s ) {
		$src = get_post_meta( $s->ID, 'mb_mp3', true );
		$out .= '<button class="track" data-src="' . esc_url( $src ) . '"><span class="tn">' . sprintf( '%02d', $i + 1 ) . '</span><span><b>' . esc_html( get_the_title( $s ) ) . '</b><small>' . esc_html( get_post_meta( $s->ID, 'mb_sub', true ) ) . '</small></span><span class="tt"></span><span class="tp"><span class="eq"><i></i><i></i><i></i></span>▶</span></button>';
	}
	return $out;
}
function mb_first_song() {
	$s = mb_posts( 'mb_song', array( 'numberposts' => 1, 'meta_key' => 'mb_mp3', 'meta_compare' => '!=', 'meta_value' => '' ) );
	return $s ? array( 'src' => get_post_meta( $s[0]->ID, 'mb_mp3', true ), 'title' => get_the_title( $s[0] ) ) : null;
}
function mb_gallery_items() {
	$ph = mb_posts( 'mb_photo' );
	$out = ''; $pat = array( 't', '', 'w', 't', '', 'w', '', '' );
	foreach ( $ph as $i => $p ) {
		$img = get_the_post_thumbnail_url( $p, 'large' );
		if ( ! $img ) continue;
		$out .= '<button class="gi ' . $pat[ $i % 8 ] . '"><img src="' . esc_url( $img ) . '" alt="' . esc_attr( get_the_title( $p ) ) . '" loading="lazy"></button>';
	}
	return $out;
}
function mb_show_rows( $when, $limit = -1 ) {
	$today = current_time( 'Y-m-d' );
	$shows = mb_posts( 'mb_show', array( 'numberposts' => $limit, 'meta_key' => 'mb_date', 'orderby' => 'meta_value', 'order' => $when === 'past' ? 'DESC' : 'ASC',
		'meta_query' => array( array( 'key' => 'mb_date', 'value' => $today, 'compare' => $when === 'past' ? '<' : '>=', 'type' => 'DATE' ) ) ) );
	$out = '';
	foreach ( $shows as $s ) {
		$d = get_post_meta( $s->ID, 'mb_date', true );
		$ts = $d ? strtotime( $d ) : 0;
		$out .= '<div class="row"><div class="d">' . esc_html( $ts ? date_i18n( 'j M', $ts ) : '' ) . '<small>' . esc_html( get_post_meta( $s->ID, 'mb_label', true ) ) . '</small></div><h4>' . esc_html( get_the_title( $s ) ) . '</h4><p>' . esc_html( get_post_meta( $s->ID, 'mb_details', true ) ) . '</p>'
			. ( $when === 'past' ? '<span class="pill" data-i18n="performed">PERFORMED</span>' : '<a class="btn solid" href="' . mb_url( 'book' ) . '" style="height:50px" data-i18n="bookNow">Book now</a>' ) . '</div>';
	}
	return $out;
}
function mb_testimonial_cards() {
	$ts = mb_posts( 'mb_testimonial' );
	$out = '';
	foreach ( $ts as $t ) {
		$out .= '<div class="tcard reveal"><div class="qq">“</div><p>' . esc_html( get_post_meta( $t->ID, 'mb_quote', true ) ) . '</p><div class="by"><span><b>' . esc_html( get_the_title( $t ) ) . '</b>' . esc_html( get_post_meta( $t->ID, 'mb_role', true ) ) . '</span></div></div>';
	}
	return $out;
}
function mb_booked_dates() {
	$dates = array();
	foreach ( preg_split( '/\R/', (string) get_theme_mod( 'mb_blocked', '' ) ) as $l ) { $l = trim( $l ); if ( preg_match( '/^\d{4}-\d{2}-\d{2}$/', $l ) ) $dates[] = $l; }
	foreach ( mb_posts( 'mb_show', array( 'meta_key' => 'mb_date', 'meta_query' => array( array( 'key' => 'mb_date', 'value' => current_time( 'Y-m-d' ), 'compare' => '>=', 'type' => 'DATE' ) ) ) ) as $s ) {
		$dates[] = get_post_meta( $s->ID, 'mb_date', true );
	}
	return array_values( array_unique( array_filter( $dates ) ) );
}
