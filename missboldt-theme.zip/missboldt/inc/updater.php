<?php
/**
 * Self-updates: the theme checks missboldt.netlify.app for a newer version
 * and installs it automatically. Content (videos, songs, bookings…) is
 * stored in WordPress itself and is never touched by an update.
 */
if ( ! defined( 'ABSPATH' ) ) exit;

define( 'MB_UPDATE_URL', 'https://raw.githubusercontent.com/olonadeabiodun44-glitch/missboldt-theme/main/update.json' );

function mb_remote_info( $force = false ) {
	$info = $force ? false : get_transient( 'mb_remote_info' );
	if ( false === $info ) {
		$r = wp_remote_get( MB_UPDATE_URL . '?t=' . time(), array( 'timeout' => 10 ) );
		$info = ( ! is_wp_error( $r ) && 200 === wp_remote_retrieve_response_code( $r ) )
			? json_decode( wp_remote_retrieve_body( $r ), true ) : array();
		set_transient( 'mb_remote_info', $info, 30 * MINUTE_IN_SECONDS );
	}
	return is_array( $info ) ? $info : array();
}

/* tell WordPress when a newer version exists */
add_filter( 'pre_set_site_transient_update_themes', function ( $t ) {
	if ( ! is_object( $t ) ) return $t;
	$slug = get_template();
	$info = mb_remote_info();
	if ( ! empty( $info['version'] ) && ! empty( $info['package'] )
		&& version_compare( $info['version'], wp_get_theme( $slug )->get( 'Version' ), '>' ) ) {
		$t->response[ $slug ] = array(
			'theme'       => $slug,
			'new_version' => $info['version'],
			'url'         => 'https://github.com/olonadeabiodun44-glitch/missboldt-theme',
			'package'     => $info['package'],
		);
	} elseif ( isset( $t->response[ $slug ] ) ) {
		unset( $t->response[ $slug ] );
	}
	return $t;
} );

/* allow WordPress' own background auto-update for this theme */
add_filter( 'auto_update_theme', function ( $update, $item ) {
	return ( isset( $item->theme ) && $item->theme === get_template() ) ? true : $update;
}, 10, 2 );

/* check every 15 minutes (runs when the site gets a visit) and install */
add_filter( 'cron_schedules', function ( $s ) {
	$s['mb_15min'] = array( 'interval' => 15 * MINUTE_IN_SECONDS, 'display' => 'Every 15 minutes' );
	return $s;
} );
add_action( 'init', function () {
	if ( ! wp_next_scheduled( 'mb_check_update' ) ) wp_schedule_event( time() + 60, 'mb_15min', 'mb_check_update' );
} );
add_action( 'mb_check_update', 'mb_do_update' );

function mb_do_update() {
	$slug = get_template();
	$info = mb_remote_info( true );
	if ( empty( $info['version'] ) || ! version_compare( $info['version'], wp_get_theme( $slug )->get( 'Version' ), '>' ) ) return false;
	if ( get_transient( 'mb_updating' ) ) return false;
	set_transient( 'mb_updating', 1, 5 * MINUTE_IN_SECONDS );
	delete_site_transient( 'update_themes' );
	wp_update_themes();
	require_once ABSPATH . 'wp-admin/includes/file.php';
	require_once ABSPATH . 'wp-admin/includes/misc.php';
	require_once ABSPATH . 'wp-admin/includes/theme.php';
	require_once ABSPATH . 'wp-admin/includes/class-wp-upgrader.php';
	$up  = new Theme_Upgrader( new Automatic_Upgrader_Skin() );
	$res = $up->upgrade( $slug );
	delete_transient( 'mb_updating' );
	update_option( 'mb_last_update', array( 'time' => time(), 'version' => $info['version'], 'ok' => ( true === $res ) ) );
	return $res;
}

/* "Update design now" link on the Themes page + Dashboard note */
add_action( 'admin_post_mb_update_now', function () {
	if ( ! current_user_can( 'update_themes' ) ) wp_die( 'Not allowed' );
	check_admin_referer( 'mb_update_now' );
	$r = mb_do_update();
	wp_safe_redirect( admin_url( 'themes.php?mb_updated=' . ( $r ? '1' : '0' ) ) );
	exit;
} );
add_action( 'admin_notices', function () {
	if ( ! current_user_can( 'update_themes' ) ) return;
	$s = get_current_screen();
	if ( ! $s || ! in_array( $s->id, array( 'themes', 'dashboard' ), true ) ) return;
	$cur  = wp_get_theme( get_template() )->get( 'Version' );
	$info = mb_remote_info();
	$new  = ( ! empty( $info['version'] ) && version_compare( $info['version'], $cur, '>' ) ) ? $info['version'] : '';
	$url  = wp_nonce_url( admin_url( 'admin-post.php?action=mb_update_now' ), 'mb_update_now' );
	echo '<div class="notice notice-info"><p><strong>Miss Boldt design</strong> · version ' . esc_html( $cur ) . ' · updates install automatically.';
	if ( isset( $_GET['mb_updated'] ) ) echo ' ' . ( '1' === $_GET['mb_updated'] ? '✅ Updated.' : 'Already up to date.' );
	if ( $new ) echo ' New version ' . esc_html( $new ) . ' is ready — <a href="' . esc_url( $url ) . '">update now</a>.';
	echo '</p></div>';
} );
