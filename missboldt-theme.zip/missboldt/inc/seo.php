<?php
/**
 * SEO · AEO · GEO: page titles & descriptions, structured data (schema.org),
 * llms.txt for AI tools, and a clean index (no author archives).
 */
if ( ! defined( 'ABSPATH' ) ) exit;

function mb_seo_pages() {
	return array(
		'home'  => array(
			'title' => 'Niomi Boldt · Wellness Speaker, Singer & Dancer | Miss Boldt',
			'desc'  => 'Book Miss Boldt (Niomi Boldt) for wellness talks, live singing and storytelling dance that heal. Life coaching in English, German and Akan. Germany & worldwide.',
		),
		'live'  => array(
			'title' => 'Live Music & Dance Performances · Miss Boldt (Niomi Boldt)',
			'desc'  => 'Watch Miss Boldt live: soulful unplugged singing, storytelling dance and the 99 Healing Project videos. Book a healing performance for your event.',
		),
		'about' => array(
			'title' => 'About Niomi Boldt · Life Coach, Speaker & Talks | Miss Boldt',
			'desc'  => 'Meet Niomi Boldt (Miss Boldt): singer, dancer, speaker and life coach. 500+ people coached, 9 natural healing methods and 6 talk themes.',
		),
		'book'  => array(
			'title' => 'Book Miss Boldt · Wellness Talk, Singing & Dance for Events',
			'desc'  => 'Check free dates and request Miss Boldt for your retreat, festival, school, company or celebration. Free and non-binding; travel included in every quote.',
		),
	);
}

function mb_seo_current() {
	$p = mb_seo_pages();
	$k = mb_page();
	return isset( $p[ $k ] ) ? $p[ $k ] : null;
}

add_filter( 'pre_get_document_title', function ( $t ) {
	$c = mb_seo_current();
	return $c ? $c['title'] : $t;
}, 20 );

function mb_seo_desc() {
	$c = mb_seo_current();
	return $c ? $c['desc'] : mb_seo_pages()['home']['desc'];
}

function mb_sameas() {
	$links = array( 'https://www.youtube.com/@niomibtv' );
	foreach ( array( 'mb_youtube', 'mb_facebook', 'mb_instagram' ) as $k ) {
		$u = trim( (string) get_theme_mod( $k, '' ) );
		if ( $u && preg_match( '#^https?://[^/]+/.+#', $u ) ) $links[] = $u;
	}
	return array_values( array_unique( $links ) );
}

/* ---------- structured data ---------- */
add_action( 'wp_head', function () {
	if ( is_admin() ) return;
	$home   = home_url( '/' );
	$person = $home . '#niomi';
	$org    = $home . '#enterwellness';
	$page   = mb_page();
	$url    = $page === 'home' ? $home : home_url( '/' . $page . '/' );
	$email  = mb_opt( 'mb_email', 'niomiboldt@gmail.com' );

	$graph = array(
		array(
			'@type'         => 'Person',
			'@id'           => $person,
			'name'          => 'Niomi Boldt',
			'alternateName' => array( 'Miss Boldt' ),
			'url'           => $home,
			'image'         => MB_URI . '/img/portrait.jpg',
			'jobTitle'      => 'Singer, dancer, speaker and life coach',
			'description'   => 'Niomi Boldt, known as Miss Boldt, is a singer, storytelling dancer, speaker and life coach. Her approach, ENTER~wellness, blends entertainment and wellness: music, movement and a healthy lifestyle, together with nature, to activate healing in body, mind and soul. She has coached over 500 people in Ghana and abroad and performs in Germany and worldwide.',
			'knowsLanguage' => array( 'English', 'German', 'Akan (Twi, Fanti)' ),
			'knowsAbout'    => array( 'Wellness coaching', 'Healing through music', 'Dance', 'Public speaking', 'Healthy lifestyle', 'Meal planning', 'Trauma healing', 'Forgiveness and tolerance' ),
			'email'         => $email,
			'sameAs'        => mb_sameas(),
		),
		array(
			'@type'       => 'ProfessionalService',
			'@id'         => $org,
			'name'        => 'Miss Boldt · ENTER~wellness',
			'url'         => $home,
			'logo'        => MB_URI . '/img/icon-512.png',
			'image'       => MB_URI . '/img/share.jpg',
			'description' => 'Wellness talks, live singing, storytelling dance and life coaching by Niomi Boldt, for retreats, festivals, schools, companies and celebrations.',
			'founder'     => array( '@id' => $person ),
			'email'       => $email,
			'areaServed'  => array( 'Germany', 'Worldwide' ),
			'sameAs'      => mb_sameas(),
			'hasOfferCatalog' => array(
				'@type' => 'OfferCatalog',
				'name'  => 'ENTER~wellness experiences',
				'itemListElement' => array_map( function ( $n ) {
					return array( '@type' => 'Offer', 'itemOffered' => array( '@type' => 'Service', 'name' => $n[0], 'description' => $n[1] ) );
				}, array(
					array( 'Wellness talk', 'Talks and Q&A on healing, purpose and a healthy lifestyle, 20–45 minutes.' ),
					array( 'Live singing', 'Unplugged, soulful live singing with a healing message.' ),
					array( 'Storytelling dance', 'Stories told through movement; everyone joins, all ages.' ),
					array( 'The full ENTER~wellness experience', 'Talk, song and dance in one 60–90 minute session.' ),
					array( 'Life coaching', 'One-to-one wellness coaching: meal planning, basic exercises and a lifestyle mindset.' ),
				) ),
			),
		),
		array(
			'@type'      => 'WebSite',
			'@id'        => $home . '#website',
			'url'        => $home,
			'name'       => 'Miss Boldt · ENTER~wellness',
			'inLanguage' => array( 'en', 'de', 'ak' ),
			'publisher'  => array( '@id' => $org ),
		),
		array(
			'@type'       => 'WebPage',
			'@id'         => $url . '#webpage',
			'url'         => $url,
			'name'        => wp_get_document_title(),
			'description' => mb_seo_desc(),
			'isPartOf'    => array( '@id' => $home . '#website' ),
			'about'       => array( '@id' => $person ),
			'inLanguage'  => 'en',
		),
	);

	if ( $page === 'book' ) {
		$faq = array(
			array( 'Does Miss Boldt travel for events?', 'Yes. Across Germany and worldwide. Travel is included in every quote.' ),
			array( 'Which languages does Miss Boldt perform in?', 'English, German and Akan (Twi/Fanti), her mother tongue from Ghana. Talks can mix languages for diverse audiences.' ),
			array( 'How long is a performance?', 'A talk runs 20–45 minutes. The full 3-in-1 experience runs 60–90 minutes. Everything can be adjusted.' ),
			array( 'Can the talk match our theme?', 'Yes. Pick one of her six topics or share your theme, and she tailors the talk to it.' ),
			array( 'Is sending a booking request binding?', 'No. It is free and non-binding. You receive a personal proposal first.' ),
		);
		$graph[] = array(
			'@type'      => 'FAQPage',
			'@id'        => $url . '#faq',
			'mainEntity' => array_map( function ( $q ) {
				return array( '@type' => 'Question', 'name' => $q[0], 'acceptedAnswer' => array( '@type' => 'Answer', 'text' => $q[1] ) );
			}, $faq ),
		);
	}

	echo '<script type="application/ld+json">' . wp_json_encode( array( '@context' => 'https://schema.org', '@graph' => $graph ), JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE ) . "</script>\n";
}, 5 );

/* ---------- llms.txt: a plain summary for AI tools ---------- */
function mb_llms_txt() {
	$h = home_url( '/' );
	return "# Miss Boldt · ENTER~wellness (Niomi Boldt)\n\n"
		. "> Niomi Boldt, known as Miss Boldt, is a singer, storytelling dancer, speaker and life coach. Her approach, ENTER~wellness, blends entertainment and wellness: music, movement and a healthy lifestyle, together with nature, to activate healing in body, mind and soul. She performs and speaks in English, German and Akan (Twi, Fanti), in Germany and worldwide.\n\n"
		. "## Key facts\n"
		. "- 6+ years of healing work; over 500 people coached in Ghana and abroad\n"
		. "- Offers: wellness talks (20–45 min), live singing, storytelling dance, and the full 3-in-1 experience (60–90 min); one-to-one life coaching\n"
		. "- 9 natural healing methods: dance, sing, be a child, speak, eat, fitness & flexibility, self care & love, believe, celebrate\n"
		. "- Talk themes: healing from trauma, healthy lifestyle, purpose, forgiveness & tolerance, owning mistakes, building a dream life\n"
		. "- Audiences: wellness retreats, festivals, tolerance & diversity days, schools & youth work, corporate wellbeing, private celebrations, community events\n"
		. "- Travel included in every quote; booking requests are free and non-binding\n\n"
		. "## Pages\n"
		. "- [Home](" . $h . "): overview of Miss Boldt and ENTER~wellness\n"
		. "- [Live & Music](" . home_url( '/live/' ) . "): videos, music and shows\n"
		. "- [About & Talks](" . home_url( '/about/' ) . "): her story, coaching, the 9 healing methods and talk themes\n"
		. "- [Book](" . home_url( '/book/' ) . "): availability calendar, booking request and FAQ\n\n"
		. "## Contact\n"
		. "- Email: " . mb_opt( 'mb_email', 'niomiboldt@gmail.com' ) . "\n"
		. "- YouTube: https://www.youtube.com/@niomibtv\n";
}
add_action( 'parse_request', function () {
	$path = isset( $_SERVER['REQUEST_URI'] ) ? strtok( $_SERVER['REQUEST_URI'], '?' ) : '';
	if ( '/llms.txt' === $path ) {
		header( 'Content-Type: text/plain; charset=utf-8' );
		header( 'Cache-Control: public, max-age=3600' );
		echo mb_llms_txt();
		exit;
	}
}, 0 );

/* ---------- clean index ---------- */
add_filter( 'wp_sitemaps_add_provider', function ( $provider, $name ) {
	return in_array( $name, array( 'users', 'taxonomies' ), true ) ? false : $provider;
}, 10, 2 );
add_filter( 'wp_sitemaps_post_types', function ( $types ) {
	return array_intersect_key( $types, array( 'page' => 1 ) );
} );
add_action( 'template_redirect', function () {
	if ( is_author() || is_date() || is_attachment() || ( is_search() && ! is_admin() ) ) {
		wp_safe_redirect( home_url( '/' ), 301 );
		exit;
	}
}, 2 );
