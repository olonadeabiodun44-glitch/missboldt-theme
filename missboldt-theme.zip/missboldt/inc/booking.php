<?php
/**
 * Booking requests: saved in WordPress (Booking requests menu) and emailed to Miss Boldt.
 */
if ( ! defined( 'ABSPATH' ) ) exit;

add_action( 'init', function () {
	register_post_type( 'mb_booking', array(
		'labels' => array( 'name' => 'Booking requests', 'singular_name' => 'Booking request', 'menu_name' => 'Booking requests', 'edit_item' => 'Booking request', 'all_items' => 'All requests' ),
		'public' => false, 'show_ui' => true, 'show_in_menu' => true, 'menu_icon' => 'dashicons-email-alt', 'menu_position' => 20,
		'supports' => array( 'title', 'editor' ), 'capability_type' => 'post', 'capabilities' => array( 'create_posts' => 'do_not_allow' ), 'map_meta_cap' => true,
	) );
} );

function mb_handle_booking() {
	if ( ! isset( $_POST['nonce'] ) || ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['nonce'] ) ), 'mb_booking' ) ) wp_send_json_error( 'bad nonce', 403 );
	$ip = isset( $_SERVER['REMOTE_ADDR'] ) ? sanitize_text_field( wp_unslash( $_SERVER['REMOTE_ADDR'] ) ) : '';
	$key = 'mb_bk_' . md5( $ip );
	if ( get_transient( $key ) ) wp_send_json_error( 'slow down', 429 );
	set_transient( $key, 1, 20 );

	$f = isset( $_POST['f'] ) && is_array( $_POST['f'] ) ? wp_unslash( $_POST['f'] ) : array();
	$clean = array();
	foreach ( $f as $k => $v ) { $clean[ sanitize_text_field( $k ) ] = sanitize_textarea_field( $v ); }
	$name  = $clean['Name'] ?? '';
	$email = isset( $clean['Email'] ) ? sanitize_email( $clean['Email'] ) : '';
	if ( ! $name || ! is_email( $email ) ) wp_send_json_error( 'missing', 400 );

	$lines = array();
	foreach ( $clean as $k => $v ) $lines[] = $k . ': ' . $v;
	$body = implode( "\n", $lines );
	$title = $name . ' · ' . ( $clean['Date'] ?? '' ) . ' · ' . ( $clean['Location'] ?? '' );
	$id = wp_insert_post( array( 'post_type' => 'mb_booking', 'post_status' => 'private', 'post_title' => $title, 'post_content' => $body ) );
	if ( $id && ! is_wp_error( $id ) ) {
		update_post_meta( $id, 'mb_email', $email );
		update_post_meta( $id, 'mb_event_date', sanitize_text_field( wp_unslash( $_POST['date_iso'] ?? '' ) ) );
	}
	$to = get_theme_mod( 'mb_booking_email', '' ) ?: 'niomiboldt@gmail.com';
	$sent = wp_mail( $to, 'New booking request · ' . $title, "New booking request from the Miss Boldt website\n\n" . $body . "\n\nAlso saved in WordPress → Booking requests.", array( 'Reply-To: ' . $name . ' <' . $email . '>' ) );
	/* confirmation for the person who booked */
	$ui   = sanitize_key( wp_unslash( $_POST['ui_lang'] ?? 'en' ) );
	$owner_reply = get_theme_mod( 'mb_email', '' ) ?: $to;
	$first = trim( strtok( $name, ' ' ) );
	if ( 'de' === $ui ) {
		$subj = 'Deine Anfrage an Miss Boldt ist angekommen';
		$msg  = "Hallo $first,\n\nvielen Dank für deine Anfrage! Miss Boldt hat sie erhalten und meldet sich persönlich bei dir mit einem passenden Plan und Angebot.\n\nDeine Angaben:\n\n" . $body
			. "\n\nDu möchtest etwas ergänzen? Antworte einfach auf diese E-Mail.\n\nHerzliche Grüße\nMiss Boldt · ENTER~wellness\n" . home_url( '/' );
	} else {
		$subj = 'Your booking request to Miss Boldt has been received';
		$msg  = "Hello $first,\n\nThank you for your request! Miss Boldt has received it and will reply to you personally with a tailored plan and quote.\n\nYour details:\n\n" . $body
			. "\n\nWant to add something? Just reply to this email.\n\nWarm regards\nMiss Boldt · ENTER~wellness\n" . home_url( '/' );
	}
	$confirmed = wp_mail( $email, $subj, $msg, array( 'Reply-To: Miss Boldt <' . $owner_reply . '>' ) );
	if ( $id && ! is_wp_error( $id ) ) update_post_meta( $id, 'mb_confirm_sent', $confirmed ? 'yes' : 'no' );
	wp_send_json_success( array( 'saved' => (bool) $id, 'mailed' => (bool) $sent, 'confirmed' => (bool) $confirmed ) );
}
add_action( 'wp_ajax_mb_booking', 'mb_handle_booking' );
add_action( 'wp_ajax_nopriv_mb_booking', 'mb_handle_booking' );

/* list columns */
add_filter( 'manage_mb_booking_posts_columns', function ( $c ) {
	return array( 'cb' => $c['cb'], 'title' => 'Request', 'mb_email' => 'Email', 'mb_event' => 'Event date', 'date' => 'Received' );
} );
add_action( 'manage_mb_booking_posts_custom_column', function ( $col, $id ) {
	if ( $col === 'mb_email' ) { $e = get_post_meta( $id, 'mb_email', true ); echo '<a href="mailto:' . esc_attr( $e ) . '">' . esc_html( $e ) . '</a>'; }
	if ( $col === 'mb_event' ) echo esc_html( get_post_meta( $id, 'mb_event_date', true ) );
}, 10, 2 );

/* nicer sender for website emails */
add_filter( 'wp_mail_from_name', function ( $n ) { return 'WordPress' === $n ? 'Miss Boldt Website' : $n; } );
add_filter( 'wp_mail_from', function ( $e ) {
	$host = wp_parse_url( home_url(), PHP_URL_HOST );
	return ( 0 === strpos( $e, 'wordpress@' ) && $host ) ? 'bookings@' . preg_replace( '/^www\./', '', $host ) : $e;
} );
